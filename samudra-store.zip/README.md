# Samudra Store POS

Point of Sale system untuk Samudra Store, Malioboro, Jogja.

## Setup

### Docker (Recommended)
```bash
docker-compose up -d
```
Akses:
- App: http://localhost:8080
- phpMyAdmin: http://localhost:8081

### XAMPP
1. Copy folder ke `htdocs/samudra-store`
2. Import `database.sql` ke MySQL
3. Edit `config.php`: ubah `DB_HOST` ke `localhost`, `DB_PASS` sesuai XAMPP
4. Akses: http://localhost/samudra-store

## Default Login
- Username: `admin`
- Password: `password`

## Secret Key Registrasi
Default: `Samudra Store` (sama dengan nama toko, bisa diubah di `config.php` → `STORE_SECRET`)

## Fitur
- ✅ Dashboard dengan statistik
- ✅ POS/Kasir dengan input SKU & grid produk
- ✅ Manajemen Produk (CRUD + SKU auto-generate)
- ✅ Manajemen Kategori (CRUD + alias 3 char untuk SKU)
- ✅ Riwayat Transaksi + filter tanggal
- ✅ Detail transaksi + print/download struk
- ✅ Manajemen Kasir (daftar, lihat profil, hapus)
- ✅ Profile (view & edit terpisah, ganti password)
- ✅ Auth dengan secret key registrasi

## Struktur SKU
Format: `ALIAS-NAMA-BERAT`
- ALIAS: 3 huruf dari alias kategori (contoh: MNM, MKN, SNK)
- NAMA: 4 huruf pertama nama produk
- BERAT: berat dalam gram

Contoh: `MNM-AQUA-600` untuk Aqua 600ml kategori Minuman
