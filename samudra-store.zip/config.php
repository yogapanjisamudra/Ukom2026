<?php
// Samudra Store Config
define('STORE_NAME', 'Samudra Store');
define('STORE_LOCATION', 'Malioboro, Jogja');
define('STORE_SECRET', STORE_NAME); // default secret = store name

// Database
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_NAME', getenv('DB_NAME') ?: 'samudra_store_db');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');

// Base URL
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'];
define('BASE_URL', $protocol . '://' . $host);

// Session - must be started before any output
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


// DB Connection (mysqli)
function db_connect() {
    $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if (!$conn) {
        die('DB Connection failed: ' . mysqli_connect_error());
    }
    mysqli_set_charset($conn, 'utf8mb4');
    return $conn;
}

function db() {
    static $conn = null;
    if ($conn === null) {
        $conn = db_connect();
    }
    return $conn;
}

// Auth helpers
function is_logged_in() {
    return isset($_SESSION['cashier_id']);
}

function require_login() {
    if (!is_logged_in()) {
        header('Location: ' . BASE_URL . '/login.php');
        exit;
    }
}

function current_cashier() {
    if (!is_logged_in()) return null;
    $conn = db();
    $id = (int)$_SESSION['cashier_id'];
    $res = mysqli_query($conn, "SELECT * FROM cashiers WHERE id = $id LIMIT 1");
    return mysqli_fetch_assoc($res);
}

// Sanitize
function e($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

function sanitize($str) {
    return mysqli_real_escape_string(db(), $str);
}

// Flash messages
function set_flash($type, $msg) {
    $_SESSION['flash'] = ['type' => $type, 'msg' => $msg];
}

function get_flash() {
    if (isset($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $f;
    }
    return null;
}

// Generate transaction code
function gen_trx_code() {
    $conn = db();
    $date = date('Ymd');
    $res = mysqli_query($conn, "SELECT COUNT(*) as c FROM transactions WHERE DATE(created_at) = CURDATE()");
    $row = mysqli_fetch_assoc($res);
    $seq = str_pad($row['c'] + 1, 4, '0', STR_PAD_LEFT);
    return "TRX-{$date}-{$seq}";
}

// Generate SKU
function gen_sku($alias, $name, $weight) {
    $alias = strtoupper(substr($alias, 0, 3));
    $name_part = strtoupper(preg_replace('/[^A-Z0-9]/i', '', substr($name, 0, 4)));
    $weight_part = $weight;
    return "{$alias}-{$name_part}-{$weight_part}";
}
