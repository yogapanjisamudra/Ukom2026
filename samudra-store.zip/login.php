<?php
require_once 'config.php';
if (is_logged_in()) {
    header('Location: ' . BASE_URL . '/index.php');
    exit;
}

$error = '';
$mode = $_GET['mode'] ?? 'login'; // login | register

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'login') {
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        if (!$username || !$password) {
            $error = 'Username dan password wajib diisi.';
        } else {
            $conn = db();
            $u = sanitize($username);
            $res = mysqli_query($conn, "SELECT * FROM cashiers WHERE username='$u' LIMIT 1");
            $cashier = mysqli_fetch_assoc($res);
            if ($cashier && password_verify($password, $cashier['password'])) {
                $_SESSION['cashier_id'] = $cashier['id'];
                header('Location: ' . BASE_URL . '/index.php');
                exit;
            } else {
                $error = 'Username atau password salah.';
            }
        }
    }

    if ($action === 'register') {
        $username = trim($_POST['username'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $secret = trim($_POST['secret'] ?? '');

        if (!$username || !$email || !$password || !$secret) {
            $error = 'Semua field wajib diisi.';
        } elseif ($secret !== STORE_SECRET) {
            $error = 'Secret key tidak valid.';
        } elseif (strlen($password) < 6) {
            $error = 'Password minimal 6 karakter.';
        } else {
            $conn = db();
            $u = sanitize($username);
            $e = sanitize($email);
            $check = mysqli_query($conn, "SELECT id FROM cashiers WHERE username='$u' OR email='$e' LIMIT 1");
            if (mysqli_num_rows($check) > 0) {
                $error = 'Username atau email sudah digunakan.';
            } else {
                $hashed = password_hash($password, PASSWORD_BCRYPT);
                $hp = sanitize($hashed);
                mysqli_query($conn, "INSERT INTO cashiers (username, email, password) VALUES ('$u','$e','$hp')");
                set_flash('success', 'Akun berhasil dibuat! Silakan login.');
                header('Location: ' . BASE_URL . '/login.php');
                exit;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $mode === 'register' ? 'Daftar Akun' : 'Login' ?> — <?= e(STORE_NAME) ?></title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<?php
$flash = get_flash();
?>
<div class="login-page">
  <div class="login-bg"></div>
  <div class="login-grid"></div>

  <div class="login-card">
    <div class="login-logo">
      <div class="name"><?= e(STORE_NAME) ?></div>
      <div class="sub"><?= e(STORE_LOCATION) ?></div>
      <span class="pos-tag">POINT OF SALE</span>
    </div>

    <?php if ($flash): ?>
    <div class="flash flash-<?= e($flash['type']) ?>" style="margin-bottom:16px">
      <i class="fa <?= $flash['type']==='success'?'fa-check-circle':'fa-triangle-exclamation' ?>"></i>
      <?= e($flash['msg']) ?>
    </div>
    <?php endif; ?>

    <?php if ($error): ?>
    <div class="flash flash-error" style="margin-bottom:16px">
      <i class="fa fa-triangle-exclamation"></i> <?= e($error) ?>
    </div>
    <?php endif; ?>

    <?php if ($mode === 'login'): ?>
    <form method="POST">
      <input type="hidden" name="action" value="login">
      <div class="form-group">
        <label class="form-label">Username</label>
        <input type="text" name="username" class="form-control" placeholder="Masukkan username" autofocus required>
      </div>
      <div class="form-group">
        <label class="form-label">Password</label>
        <input type="password" name="password" class="form-control" placeholder="Masukkan password" required>
      </div>
      <button type="submit" class="btn btn-primary w-full btn-lg" style="margin-top:8px">
        <i class="fa fa-right-to-bracket"></i> Login
      </button>
    </form>
    <div class="text-center mt-16" style="color:var(--text3);font-size:13px">
      Belum punya akun?
      <a href="?mode=register" style="color:var(--accent);text-decoration:none">Daftar di sini</a>
    </div>

    <?php else: ?>
    <form method="POST">
      <input type="hidden" name="action" value="register">
      <div class="form-group">
        <label class="form-label">Username</label>
        <input type="text" name="username" class="form-control" placeholder="Username" autofocus required>
      </div>
      <div class="form-group">
        <label class="form-label">Email</label>
        <input type="email" name="email" class="form-control" placeholder="Email" required>
      </div>
      <div class="form-group">
        <label class="form-label">Password</label>
        <input type="password" name="password" class="form-control" placeholder="Min. 6 karakter" required>
      </div>
      <div class="form-group">
        <label class="form-label">Secret Key</label>
        <input type="password" name="secret" class="form-control" placeholder="Secret key dari admin" required>
      </div>
      <button type="submit" class="btn btn-success w-full btn-lg" style="margin-top:8px">
        <i class="fa fa-user-plus"></i> Daftar
      </button>
    </form>
    <div class="text-center mt-16" style="color:var(--text3);font-size:13px">
      Sudah punya akun?
      <a href="?mode=login" style="color:var(--accent);text-decoration:none">Login di sini</a>
    </div>
    <?php endif; ?>
  </div>
</div>
</body>
</html>
