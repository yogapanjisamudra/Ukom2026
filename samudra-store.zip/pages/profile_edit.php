<?php
require_once dirname(__DIR__) . '/config.php';
require_login();

$conn = db();
$current = current_cashier();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'update_info') {
        $username = trim($_POST['username'] ?? '');
        $email = trim($_POST['email'] ?? '');
        if (!$username || !$email) {
            $errors[] = 'Username dan email wajib diisi.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Format email tidak valid.';
        } else {
            $id = (int)$current['id'];
            $u = sanitize($username); $e = sanitize($email);
            $check = mysqli_query($conn, "SELECT id FROM cashiers WHERE (username='$u' OR email='$e') AND id != $id LIMIT 1");
            if (mysqli_num_rows($check) > 0) {
                $errors[] = 'Username atau email sudah digunakan.';
            } else {
                mysqli_query($conn, "UPDATE cashiers SET username='$u', email='$e' WHERE id=$id");
                set_flash('success', 'Profile berhasil diupdate.');
                header('Location: ' . BASE_URL . '/pages/profile.php');
                exit;
            }
        }
    }

    if ($action === 'change_password') {
        $old_pass = $_POST['old_password'] ?? '';
        $new_pass = $_POST['new_password'] ?? '';
        $confirm_pass = $_POST['confirm_password'] ?? '';
        if (!$old_pass || !$new_pass || !$confirm_pass) {
            $errors[] = 'Semua field password wajib diisi.';
        } elseif (!password_verify($old_pass, $current['password'])) {
            $errors[] = 'Password lama salah.';
        } elseif ($new_pass !== $confirm_pass) {
            $errors[] = 'Konfirmasi password tidak cocok.';
        } elseif (strlen($new_pass) < 6) {
            $errors[] = 'Password baru minimal 6 karakter.';
        } else {
            $id = (int)$current['id'];
            $hashed = password_hash($new_pass, PASSWORD_BCRYPT);
            $hp = sanitize($hashed);
            mysqli_query($conn, "UPDATE cashiers SET password='$hp' WHERE id=$id");
            set_flash('success', 'Password berhasil diubah.');
            header('Location: ' . BASE_URL . '/pages/profile.php');
            exit;
        }
    }

    $current = current_cashier();
}

$page_title = 'Edit Profile';
require_once dirname(__DIR__) . '/includes/header.php';
?>

<div style="max-width:640px;margin:0 auto">
  <div class="mb-20">
    <a href="<?= BASE_URL ?>/pages/profile.php" class="btn btn-ghost btn-sm"><i class="fa fa-arrow-left"></i> Kembali ke Profile</a>
  </div>

  <?php if ($errors): ?>
  <div class="flash flash-error mb-16">
    <i class="fa fa-triangle-exclamation"></i>
    <div><?= implode('<br>', array_map('e', $errors)) ?></div>
  </div>
  <?php endif; ?>

  <div class="card mb-20">
    <div class="card-header"><div class="card-title"><i class="fa fa-user-pen"></i> Informasi Akun</div></div>
    <div class="card-body">
      <form method="POST">
        <input type="hidden" name="action" value="update_info">
        <div class="form-group">
          <label class="form-label">Username</label>
          <input type="text" name="username" class="form-control" value="<?= e($current['username']) ?>" required>
        </div>
        <div class="form-group">
          <label class="form-label">Email</label>
          <input type="email" name="email" class="form-control" value="<?= e($current['email']) ?>" required>
        </div>
        <div class="form-group">
          <label class="form-label">Bergabung Sejak</label>
          <input type="text" class="form-control" value="<?= date('d M Y', strtotime($current['created_at'])) ?>" readonly>
        </div>
        <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Simpan Perubahan</button>
      </form>
    </div>
  </div>

  <div class="card">
    <div class="card-header"><div class="card-title"><i class="fa fa-lock"></i> Ganti Password</div></div>
    <div class="card-body">
      <form method="POST">
        <input type="hidden" name="action" value="change_password">
        <div class="form-group">
          <label class="form-label">Password Lama</label>
          <input type="password" name="old_password" class="form-control" placeholder="Masukkan password saat ini" required>
        </div>
        <div class="form-group">
          <label class="form-label">Password Baru</label>
          <input type="password" name="new_password" class="form-control" placeholder="Min. 6 karakter" required>
        </div>
        <div class="form-group">
          <label class="form-label">Konfirmasi Password Baru</label>
          <input type="password" name="confirm_password" class="form-control" placeholder="Ulangi password baru" required>
        </div>
        <button type="submit" class="btn btn-danger"><i class="fa fa-key"></i> Ganti Password</button>
      </form>
    </div>
  </div>
</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
