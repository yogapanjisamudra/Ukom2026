<?php
require_once dirname(__DIR__) . '/config.php';
require_login();

$conn = db();
$trx_id = (int)($_GET['trx'] ?? 0);

if (!$trx_id) {
    header('Location: ' . BASE_URL . '/pages/transactions.php');
    exit;
}

$res = mysqli_query($conn, "SELECT t.*, c.username as cashier_name FROM transactions t LEFT JOIN cashiers c ON c.id=t.cashier_id WHERE t.id=$trx_id LIMIT 1");
$trx = mysqli_fetch_assoc($res);

if (!$trx) {
    header('Location: ' . BASE_URL . '/pages/transactions.php');
    exit;
}

$last_trx = [
    'id' => $trx['id'],
    'kode' => $trx['kode'],
    'items' => json_decode($trx['products'], true),
    'grand_total' => $trx['grand_total'],
    'paid' => $trx['grand_total'], // for PDF we may not have paid amount, show total
    'change' => 0,
    'cashier' => $trx['cashier_name'],
    'cashier_name' => $trx['cashier_name'],
    'time' => $trx['created_at'],
    'created_at' => $trx['created_at'],
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Struk <?= e($trx['kode']) ?></title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Courier New', monospace; background: #f5f5f5; display: flex; align-items: flex-start; justify-content: center; padding: 20px; }
  .receipt { background: #fff; width: 300px; padding: 20px; font-size: 12px; line-height: 1.7; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
  .store-name { font-size: 16px; font-weight: bold; text-align: center; }
  .store-info { text-align: center; font-size: 11px; margin-bottom: 4px; }
  .divider { border-top: 1px dashed #000; margin: 8px 0; }
  .item-row { display: flex; justify-content: space-between; }
  .total-row { display: flex; justify-content: space-between; font-weight: bold; }
  .thank-you { text-align: center; margin-top: 8px; font-size: 11px; }
  .no-print-btn { margin-top: 20px; text-align: center; }
  .no-print-btn button, .no-print-btn a {
    background: #0090cc; color: #fff; border: none; padding: 10px 20px;
    cursor: pointer; font-size: 14px; margin: 0 5px; border-radius: 4px; text-decoration: none;
    display: inline-block;
  }
  .no-print-btn a.back { background: #666; }
  @media print {
    body { background: white; padding: 0; }
    .no-print-btn { display: none; }
  }
</style>
</head>
<body>
<div>
<?php include dirname(__DIR__) . '/includes/receipt_template.php'; ?>
<div class="no-print-btn">
  <button onclick="window.print()">🖨️ Print</button>
  <a href="javascript:history.back()" class="back">← Kembali</a>
</div>
</div>

<script>
// Auto trigger print dialog on load if needed
// window.onload = function() { window.print(); }
</script>
</body>
</html>
