<?php
require_once dirname(__DIR__) . '/config.php';
require_login();

$conn = db();
$current = current_cashier();

$view_id = isset($_GET['id']) ? (int)$_GET['id'] : (int)$current['id'];
$res = mysqli_query($conn, "SELECT * FROM cashiers WHERE id=$view_id LIMIT 1");
$profile = mysqli_fetch_assoc($res);

if (!$profile) {
    set_flash('error', 'Kasir tidak ditemukan.');
    header('Location: ' . BASE_URL . '/pages/cashiers.php');
    exit;
}

$is_own = $profile['id'] == $current['id'];
$stats = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as trx_count, COALESCE(SUM(grand_total),0) as total_sales, DATE(MAX(created_at)) as last_trx_date FROM transactions WHERE cashier_id=$view_id"));
$recent_trx = mysqli_query($conn, "SELECT * FROM transactions WHERE cashier_id=$view_id ORDER BY created_at DESC LIMIT 5");

$page_title = 'Profile';
require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="profile-grid">
  <div>
    <div class="profile-card mb-16">
      <div class="avatar-big"><?= strtoupper(substr($profile['username'], 0, 1)) ?></div>
      <div class="profile-username"><?= e($profile['username']) ?></div>
      <div class="profile-email"><?= e($profile['email']) ?></div>
      <div class="profile-joined">Bergabung <?= date('d M Y', strtotime($profile['created_at'])) ?></div>
      <?php if ($is_own): ?>
      <div style="margin-top:16px">
        <a href="<?= BASE_URL ?>/pages/profile_edit.php" class="btn btn-primary w-full"><i class="fa fa-pen"></i> Edit Profile</a>
      </div>
      <?php else: ?>
      <div style="margin-top:16px">
        <a href="<?= BASE_URL ?>/pages/cashiers.php" class="btn btn-secondary w-full"><i class="fa fa-arrow-left"></i> Kembali</a>
      </div>
      <?php endif; ?>
    </div>
    <div class="card">
      <div class="card-header"><div class="card-title" style="font-size:12px">Statistik</div></div>
      <div class="card-body" style="padding:16px">
        <div style="margin-bottom:12px">
          <div class="stat-label">Total Transaksi</div>
          <div style="font-family:var(--cond);font-size:24px;font-weight:700;color:var(--accent)"><?= $stats['trx_count'] ?></div>
        </div>
        <div style="margin-bottom:12px">
          <div class="stat-label">Total Penjualan</div>
          <div style="font-family:var(--cond);font-size:18px;font-weight:700;color:var(--green)">Rp <?= number_format($stats['total_sales'], 0, ',', '.') ?></div>
        </div>
        <?php if ($stats['last_trx_date']): ?>
        <div>
          <div class="stat-label">Transaksi Terakhir</div>
          <div style="font-size:13px;color:var(--text2)"><?= date('d M Y', strtotime($stats['last_trx_date'])) ?></div>
        </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
  <div>
    <div class="card">
      <div class="card-header">
        <div class="card-title"><i class="fa fa-history"></i> Transaksi Terbaru</div>
        <a href="<?= BASE_URL ?>/pages/transactions.php?q=<?= urlencode($profile['username']) ?>" class="btn btn-ghost btn-sm">Lihat Semua</a>
      </div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Kode</th><th>Items</th><th>Total</th><th>Waktu</th><th>Aksi</th></tr></thead>
          <tbody>
            <?php if (mysqli_num_rows($recent_trx) === 0): ?>
            <tr><td colspan="5" class="text-center text-muted" style="padding:24px">Belum ada transaksi</td></tr>
            <?php else: while ($row = mysqli_fetch_assoc($recent_trx)):
              $prods = json_decode($row['products'], true);
            ?>
            <tr>
              <td class="td-mono" style="font-size:11px;white-space:nowrap"><?= e($row['kode']) ?></td>
              <td style="font-size:12px;color:var(--text2)"><?= count($prods) ?> item</td>
              <td style="color:var(--green);font-weight:600;white-space:nowrap">Rp <?= number_format($row['grand_total'], 0, ',', '.') ?></td>
              <td style="font-size:11px;color:var(--text3);white-space:nowrap"><?= date('d/m H:i', strtotime($row['created_at'])) ?></td>
              <td>
                <a href="<?= BASE_URL ?>/pages/receipt_pdf.php?trx=<?= $row['id'] ?>" target="_blank" class="btn btn-secondary btn-sm"><i class="fa fa-print"></i></a>
              </td>
            </tr>
            <?php endwhile; endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
