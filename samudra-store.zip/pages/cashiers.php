<?php
require_once dirname(__DIR__) . '/config.php';
require_login();

$conn = db();
$current = current_cashier();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    $id = (int)$_POST['id'];
    if ($id === (int)$current['id']) {
        set_flash('error', 'Tidak bisa hapus akun sendiri.');
    } else {
        $check = mysqli_query($conn, "SELECT id FROM transactions WHERE cashier_id=$id LIMIT 1");
        if (mysqli_num_rows($check) > 0) {
            set_flash('error', 'Tidak bisa hapus kasir yang memiliki riwayat transaksi.');
        } else {
            mysqli_query($conn, "DELETE FROM cashiers WHERE id=$id");
            set_flash('success', 'Kasir berhasil dihapus.');
        }
    }
    header('Location: ' . BASE_URL . '/pages/cashiers.php');
    exit;
}

$search = trim($_GET['q'] ?? '');
$where = "1=1";
if ($search) $where .= " AND (username LIKE '%" . sanitize($search) . "%' OR email LIKE '%" . sanitize($search) . "%')";

$cashiers = mysqli_query($conn, "
    SELECT ca.*,
           (SELECT COUNT(*) FROM transactions t WHERE t.cashier_id = ca.id) as trx_count,
           (SELECT COALESCE(SUM(grand_total),0) FROM transactions t WHERE t.cashier_id = ca.id) as total_sales
    FROM cashiers ca
    WHERE $where
    ORDER BY ca.created_at ASC
");

$page_title = 'Manajemen Kasir';
require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="card">
  <div class="card-header">
    <div class="card-title"><i class="fa fa-users"></i> Daftar Kasir</div>
    <div class="flex gap-8">
      <form method="GET" class="flex gap-8">
        <div class="search-input-wrap">
          <span class="icon"><i class="fa fa-search"></i></span>
          <input type="text" name="q" class="form-control search-input" placeholder="Cari kasir..." value="<?= e($search) ?>" style="width:180px">
        </div>
        <button type="submit" class="btn btn-secondary btn-sm">Cari</button>
      </form>
      <a href="<?= BASE_URL ?>/login.php?mode=register" target="_blank" class="btn btn-primary btn-sm">
        <i class="fa fa-user-plus"></i> Daftar Kasir Baru
      </a>
    </div>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr><th>#</th><th>Kasir</th><th>Email</th><th>Transaksi</th><th>Total Penjualan</th><th>Bergabung</th><th>Aksi</th></tr>
      </thead>
      <tbody>
        <?php $no = 1; while ($row = mysqli_fetch_assoc($cashiers)): $isCurrent = $row['id'] == $current['id']; ?>
        <tr>
          <td class="text-muted"><?= $no++ ?></td>
          <td>
            <div style="display:flex;align-items:center;gap:10px">
              <div style="width:36px;height:36px;background:var(--accent-glow);border:1px solid var(--accent2);border-radius:50%;display:flex;align-items:center;justify-content:center;font-family:var(--cond);font-weight:700;font-size:15px;color:var(--accent);flex-shrink:0">
                <?= strtoupper(substr($row['username'], 0, 1)) ?>
              </div>
              <div>
                <div style="font-weight:600;color:var(--text)"><?= e($row['username']) ?></div>
                <?php if ($isCurrent): ?><span class="badge badge-blue" style="font-size:9px">Akun Saya</span><?php endif; ?>
              </div>
            </div>
          </td>
          <td style="color:var(--text3);font-family:var(--mono);font-size:12px"><?= e($row['email']) ?></td>
          <td><span class="badge badge-gray"><?= $row['trx_count'] ?></span></td>
          <td style="color:var(--green);font-weight:600;white-space:nowrap">Rp <?= number_format($row['total_sales'], 0, ',', '.') ?></td>
          <td style="font-size:12px;color:var(--text3);white-space:nowrap"><?= date('d M Y', strtotime($row['created_at'])) ?></td>
          <td style="white-space:nowrap">
            <div class="flex gap-8">
              <a href="<?= BASE_URL ?>/pages/profile.php?id=<?= $row['id'] ?>" class="btn btn-secondary btn-sm"><i class="fa fa-eye"></i></a>
              <?php if (!$isCurrent): ?>
              <button class="btn btn-danger btn-sm" onclick="deleteCashier(<?= $row['id'] ?>, '<?= e(addslashes($row['username'])) ?>')"><i class="fa fa-trash"></i></button>
              <?php endif; ?>
            </div>
          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>

<form method="POST" id="deleteForm" style="display:none">
  <input type="hidden" name="action" value="delete">
  <input type="hidden" name="id" id="delete_id">
</form>

<script>
function deleteCashier(id, name) {
  showConfirm('Hapus Kasir', 'Hapus akun kasir "' + name + '"?', '⚠️', function() {
    document.getElementById('delete_id').value = id;
    document.getElementById('deleteForm').submit();
  });
}
</script>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
