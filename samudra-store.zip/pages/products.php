<?php
require_once dirname(__DIR__) . '/config.php';
require_login();

$conn = db();

// ALL POST LOGIC BEFORE ANY OUTPUT
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add' || $action === 'edit') {
        $name = trim($_POST['name'] ?? '');
        $category_id = (int)($_POST['category_id'] ?? 0);
        $berat = (int)($_POST['berat'] ?? 0);
        $price = (float)str_replace(['.', ','], ['', ''], $_POST['price'] ?? 0);
        $discount = (float)($_POST['discount'] ?? 0);
        $stock = (int)($_POST['stock'] ?? 0);

        if (!$name || !$category_id || $price <= 0) {
            set_flash('error', 'Nama, kategori, dan harga wajib diisi.');
        } else {
            $res = mysqli_query($conn, "SELECT alias FROM categories WHERE id=$category_id LIMIT 1");
            $cat = mysqli_fetch_assoc($res);
            if (!$cat) {
                set_flash('error', 'Kategori tidak ditemukan.');
            } else {
                $sku = gen_sku($cat['alias'], $name, $berat);
                $n = sanitize($name);
                $s = sanitize($sku);

                if ($action === 'add') {
                    $check = mysqli_query($conn, "SELECT id FROM products WHERE sku='$s' LIMIT 1");
                    if (mysqli_num_rows($check) > 0) {
                        $sku = $sku . '-' . rand(10, 99);
                        $s = sanitize($sku);
                    }
                    mysqli_query($conn, "INSERT INTO products (name, sku, category_id, berat, price, discount, stock, sold) VALUES ('$n','$s',$category_id,$berat,$price,$discount,$stock,0)");
                    set_flash('success', "Produk berhasil ditambahkan. SKU: $sku");
                } else {
                    $id = (int)$_POST['id'];
                    $sold = (int)($_POST['sold'] ?? 0);
                    $check = mysqli_query($conn, "SELECT id FROM products WHERE sku='$s' AND id != $id LIMIT 1");
                    if (mysqli_num_rows($check) > 0) {
                        $sku = $sku . '-' . rand(10, 99);
                        $s = sanitize($sku);
                    }
                    mysqli_query($conn, "UPDATE products SET name='$n', sku='$s', category_id=$category_id, berat=$berat, price=$price, discount=$discount, stock=$stock, sold=$sold WHERE id=$id");
                    set_flash('success', 'Produk berhasil diupdate.');
                }
            }
        }
    }

    if ($action === 'delete') {
        $id = (int)$_POST['id'];
        mysqli_query($conn, "DELETE FROM products WHERE id=$id");
        set_flash('success', 'Produk berhasil dihapus.');
    }

    header('Location: ' . BASE_URL . '/pages/products.php');
    exit;
}

// BUILD DATA
$search = trim($_GET['q'] ?? '');
$cat_filter = (int)($_GET['cat'] ?? 0);
$per_page = 15;
$pg = max(1, (int)($_GET['page'] ?? 1));
$offset = ($pg - 1) * $per_page;

$where = "1=1";
if ($search) $where .= " AND (p.name LIKE '%" . sanitize($search) . "%' OR p.sku LIKE '%" . sanitize($search) . "%')";
if ($cat_filter) $where .= " AND p.category_id = $cat_filter";

$total_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM products p WHERE $where"))['c'];
$total_pages = ceil($total_count / $per_page);

$products = mysqli_query($conn, "
    SELECT p.*, c.nama as cat_name, c.alias as cat_alias
    FROM products p
    LEFT JOIN categories c ON c.id = p.category_id
    WHERE $where
    ORDER BY p.name ASC
    LIMIT $per_page OFFSET $offset
");

$categories = mysqli_query($conn, "SELECT * FROM categories ORDER BY nama ASC");
$cats_arr = [];
while ($c = mysqli_fetch_assoc($categories)) $cats_arr[] = $c;

$page_title = 'Produk';
require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="card">
  <div class="card-header">
    <div class="card-title"><i class="fa fa-box"></i> Daftar Produk</div>
    <div class="flex gap-8" style="flex-wrap:wrap">
      <form method="GET" class="flex gap-8" style="flex-wrap:wrap">
        <div class="search-input-wrap">
          <span class="icon"><i class="fa fa-search"></i></span>
          <input type="text" name="q" class="form-control search-input" placeholder="Cari produk / SKU..." value="<?= e($search) ?>" style="width:160px">
        </div>
        <select name="cat" class="form-control" style="width:130px">
          <option value="">Semua Kategori</option>
          <?php foreach ($cats_arr as $c): ?>
          <option value="<?= $c['id'] ?>" <?= $cat_filter == $c['id'] ? 'selected' : '' ?>><?= e($c['nama']) ?></option>
          <?php endforeach; ?>
        </select>
        <button type="submit" class="btn btn-secondary btn-sm">Filter</button>
        <?php if ($search || $cat_filter): ?>
        <a href="<?= BASE_URL ?>/pages/products.php" class="btn btn-ghost btn-sm">Reset</a>
        <?php endif; ?>
      </form>
      <button class="btn btn-primary btn-sm" onclick="openModal('addModal')">
        <i class="fa fa-plus"></i> Tambah
      </button>
    </div>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>#</th><th>Nama Produk</th><th>SKU</th><th>Kategori</th>
          <th>Harga</th><th>Diskon</th><th>Berat</th><th>Stok</th><th>Terjual</th><th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php if (mysqli_num_rows($products) === 0): ?>
        <tr><td colspan="10" class="text-center text-muted" style="padding:30px">Tidak ada produk ditemukan.</td></tr>
        <?php else: $no = $offset + 1; while ($row = mysqli_fetch_assoc($products)): ?>
        <tr>
          <td class="text-muted"><?= $no++ ?></td>
          <td><div style="font-weight:600;color:var(--text);min-width:120px"><?= e($row['name']) ?></div></td>
          <td class="td-mono" style="white-space:nowrap"><?= e($row['sku']) ?></td>
          <td><span class="badge badge-blue"><?= e($row['cat_name']) ?></span></td>
          <td style="color:var(--green);font-weight:600;white-space:nowrap">Rp <?= number_format($row['price'], 0, ',', '.') ?></td>
          <td><?= $row['discount'] > 0 ? '<span class="badge badge-red">'.$row['discount'].'%</span>' : '<span class="text-muted">—</span>' ?></td>
          <td class="text-muted"><?= $row['berat'] ?>g</td>
          <td>
            <span class="badge <?= $row['stock'] == 0 ? 'badge-red' : ($row['stock'] <= 5 ? 'badge-yellow' : 'badge-green') ?>">
              <?= $row['stock'] ?>
            </span>
          </td>
          <td class="text-muted"><?= $row['sold'] ?></td>
          <td style="white-space:nowrap">
            <div class="flex gap-8">
              <button class="btn btn-secondary btn-sm" onclick='editProduct(<?= json_encode($row) ?>)'><i class="fa fa-pen"></i></button>
              <button class="btn btn-danger btn-sm" onclick="deleteProduct(<?= $row['id'] ?>, '<?= e(addslashes($row['name'])) ?>')"><i class="fa fa-trash"></i></button>
            </div>
          </td>
        </tr>
        <?php endwhile; endif; ?>
      </tbody>
    </table>
  </div>
  <?php if ($total_pages > 1): ?>
  <div class="pagination">
    <?php if ($pg > 1): ?>
    <a href="?page=<?= $pg-1 ?>&q=<?= urlencode($search) ?>&cat=<?= $cat_filter ?>" class="page-btn">‹</a>
    <?php endif; ?>
    <?php for ($i = max(1,$pg-2); $i <= min($total_pages,$pg+2); $i++): ?>
    <a href="?page=<?= $i ?>&q=<?= urlencode($search) ?>&cat=<?= $cat_filter ?>" class="page-btn <?= $i==$pg?'active':'' ?>"><?= $i ?></a>
    <?php endfor; ?>
    <?php if ($pg < $total_pages): ?>
    <a href="?page=<?= $pg+1 ?>&q=<?= urlencode($search) ?>&cat=<?= $cat_filter ?>" class="page-btn">›</a>
    <?php endif; ?>
    <span style="margin-left:8px;font-size:12px;color:var(--text3)">Total <?= $total_count ?> produk</span>
  </div>
  <?php endif; ?>
</div>

<!-- Add Modal -->
<div class="modal-overlay" id="addModal">
  <div class="modal" style="max-width:580px">
    <div class="modal-header">
      <div class="modal-title">Tambah Produk</div>
      <button class="modal-close" onclick="closeModal('addModal')">✕</button>
    </div>
    <form method="POST">
      <input type="hidden" name="action" value="add">
      <div class="modal-body">
        <div class="form-row cols-2">
          <div class="form-group">
            <label class="form-label">Nama Produk *</label>
            <input type="text" name="name" class="form-control" placeholder="Nama produk" required>
          </div>
          <div class="form-group">
            <label class="form-label">Kategori *</label>
            <select name="category_id" class="form-control" required>
              <option value="">Pilih kategori</option>
              <?php foreach ($cats_arr as $c): ?>
              <option value="<?= $c['id'] ?>"><?= e($c['nama']) ?> (<?= e($c['alias']) ?>)</option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>
        <div class="form-row cols-3">
          <div class="form-group">
            <label class="form-label">Harga (Rp) *</label>
            <input type="number" name="price" class="form-control" placeholder="0" min="0" required>
          </div>
          <div class="form-group">
            <label class="form-label">Diskon (%)</label>
            <input type="number" name="discount" class="form-control" placeholder="0" min="0" max="100" value="0">
          </div>
          <div class="form-group">
            <label class="form-label">Berat (gram)</label>
            <input type="number" name="berat" class="form-control" placeholder="0" min="0" value="0">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Stok Awal</label>
          <input type="number" name="stock" class="form-control" placeholder="0" min="0" value="0">
        </div>
        <div style="font-size:12px;color:var(--text3);background:var(--bg3);padding:10px;border-radius:var(--radius);border:1px solid var(--border)">
          <i class="fa fa-info-circle"></i> SKU auto-generate: <strong>ALIAS-NAMA-BERAT</strong>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('addModal')">Batal</button>
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
    </form>
  </div>
</div>

<!-- Edit Modal -->
<div class="modal-overlay" id="editModal">
  <div class="modal" style="max-width:580px">
    <div class="modal-header">
      <div class="modal-title">Edit Produk</div>
      <button class="modal-close" onclick="closeModal('editModal')">✕</button>
    </div>
    <form method="POST">
      <input type="hidden" name="action" value="edit">
      <input type="hidden" name="id" id="ep_id">
      <div class="modal-body">
        <div class="form-group">
          <label class="form-label">SKU (Generated)</label>
          <input type="text" id="ep_sku" class="form-control" readonly style="font-family:var(--mono);font-size:12px">
        </div>
        <div class="form-row cols-2">
          <div class="form-group">
            <label class="form-label">Nama Produk *</label>
            <input type="text" name="name" id="ep_name" class="form-control" required>
          </div>
          <div class="form-group">
            <label class="form-label">Kategori *</label>
            <select name="category_id" id="ep_cat" class="form-control" required>
              <option value="">Pilih kategori</option>
              <?php foreach ($cats_arr as $c): ?>
              <option value="<?= $c['id'] ?>"><?= e($c['nama']) ?> (<?= e($c['alias']) ?>)</option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>
        <div class="form-row cols-3">
          <div class="form-group">
            <label class="form-label">Harga (Rp) *</label>
            <input type="number" name="price" id="ep_price" class="form-control" min="0" required>
          </div>
          <div class="form-group">
            <label class="form-label">Diskon (%)</label>
            <input type="number" name="discount" id="ep_discount" class="form-control" min="0" max="100">
          </div>
          <div class="form-group">
            <label class="form-label">Berat (gram)</label>
            <input type="number" name="berat" id="ep_berat" class="form-control" min="0">
          </div>
        </div>
        <div class="form-row cols-2">
          <div class="form-group">
            <label class="form-label">Stok</label>
            <input type="number" name="stock" id="ep_stock" class="form-control" min="0">
          </div>
          <div class="form-group">
            <label class="form-label">Terjual</label>
            <input type="number" name="sold" id="ep_sold" class="form-control" min="0">
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('editModal')">Batal</button>
        <button type="submit" class="btn btn-primary">Update</button>
      </div>
    </form>
  </div>
</div>

<form method="POST" id="deleteForm" style="display:none">
  <input type="hidden" name="action" value="delete">
  <input type="hidden" name="id" id="delete_id">
</form>

<script>
function editProduct(p) {
  document.getElementById('ep_id').value = p.id;
  document.getElementById('ep_sku').value = p.sku;
  document.getElementById('ep_name').value = p.name;
  document.getElementById('ep_cat').value = p.category_id;
  document.getElementById('ep_price').value = p.price;
  document.getElementById('ep_discount').value = p.discount;
  document.getElementById('ep_berat').value = p.berat;
  document.getElementById('ep_stock').value = p.stock;
  document.getElementById('ep_sold').value = p.sold;
  openModal('editModal');
}
function deleteProduct(id, name) {
  showConfirm('Hapus Produk', 'Hapus produk "' + name + '"?', '🗑️', function() {
    document.getElementById('delete_id').value = id;
    document.getElementById('deleteForm').submit();
  });
}
</script>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
