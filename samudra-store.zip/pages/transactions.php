<?php
require_once dirname(__DIR__) . '/config.php';
require_login();

$conn = db();

$search = trim($_GET['q'] ?? '');
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';
$per_page = 15;
$pg = max(1, (int)($_GET['page'] ?? 1));
$offset = ($pg - 1) * $per_page;

$where = "1=1";
if ($search) { $sq = sanitize($search); $where .= " AND (t.kode LIKE '%$sq%' OR ca.username LIKE '%$sq%')"; }
if ($date_from) $where .= " AND DATE(t.created_at) >= '" . sanitize($date_from) . "'";
if ($date_to) $where .= " AND DATE(t.created_at) <= '" . sanitize($date_to) . "'";

$total_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM transactions t LEFT JOIN cashiers ca ON ca.id=t.cashier_id WHERE $where"))['c'];
$total_pages = ceil($total_count / $per_page);
$summary = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c, COALESCE(SUM(t.grand_total),0) as total FROM transactions t LEFT JOIN cashiers ca ON ca.id=t.cashier_id WHERE $where"));

$transactions = mysqli_query($conn, "
    SELECT t.*, ca.username as cashier_name
    FROM transactions t
    LEFT JOIN cashiers ca ON ca.id = t.cashier_id
    WHERE $where
    ORDER BY t.created_at DESC
    LIMIT $per_page OFFSET $offset
");

$q_params = http_build_query(array_filter(['q'=>$search,'date_from'=>$date_from,'date_to'=>$date_to]));

$page_title = 'Riwayat Transaksi';
require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="stats-grid" style="margin-bottom:20px;grid-template-columns:repeat(auto-fit,minmax(160px,1fr))">
  <div class="stat-card blue">
    <div class="stat-label">Total Transaksi</div>
    <div class="stat-value"><?= $summary['c'] ?></div>
  </div>
  <div class="stat-card green">
    <div class="stat-label">Total Pendapatan</div>
    <div class="stat-value" style="font-size:18px">Rp <?= number_format($summary['total'], 0, ',', '.') ?></div>
  </div>
</div>

<div class="card">
  <div class="card-header">
    <div class="card-title"><i class="fa fa-receipt"></i> Riwayat Transaksi</div>
    <form method="GET" class="flex gap-8" style="flex-wrap:wrap">
      <div class="search-input-wrap">
        <span class="icon"><i class="fa fa-search"></i></span>
        <input type="text" name="q" class="form-control search-input" placeholder="Kode / Kasir..." value="<?= e($search) ?>" style="width:160px">
      </div>
      <input type="date" name="date_from" class="form-control" value="<?= e($date_from) ?>" style="width:140px">
      <input type="date" name="date_to" class="form-control" value="<?= e($date_to) ?>" style="width:140px">
      <button type="submit" class="btn btn-secondary btn-sm">Filter</button>
      <?php if ($search || $date_from || $date_to): ?>
      <a href="<?= BASE_URL ?>/pages/transactions.php" class="btn btn-ghost btn-sm">Reset</a>
      <?php endif; ?>
    </form>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr><th>#</th><th>Kode Transaksi</th><th>Kasir</th><th>Produk</th><th>Grand Total</th><th>Waktu</th><th>Aksi</th></tr>
      </thead>
      <tbody>
        <?php if (mysqli_num_rows($transactions) === 0): ?>
        <tr><td colspan="7" class="text-center text-muted" style="padding:30px">Tidak ada transaksi ditemukan.</td></tr>
        <?php else: $no = $offset + 1; while ($row = mysqli_fetch_assoc($transactions)):
          $prods = json_decode($row['products'], true);
          $prod_count = count($prods);
        ?>
        <tr>
          <td class="text-muted"><?= $no++ ?></td>
          <td class="td-mono" style="white-space:nowrap"><?= e($row['kode']) ?></td>
          <td>
            <div style="display:flex;align-items:center;gap:8px;white-space:nowrap">
              <div style="width:24px;height:24px;background:var(--accent-glow);border:1px solid var(--accent2);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:700;color:var(--accent);flex-shrink:0">
                <?= strtoupper(substr($row['cashier_name'], 0, 1)) ?>
              </div>
              <?= e($row['cashier_name']) ?>
            </div>
          </td>
          <td style="color:var(--text2);min-width:150px">
            <?= $prod_count ?> item
            <div style="font-size:10px;color:var(--text3)">
              <?= e(implode(', ', array_slice(array_column($prods, 'name'), 0, 2))) ?><?= $prod_count > 2 ? '...' : '' ?>
            </div>
          </td>
          <td style="color:var(--green);font-weight:600;font-family:var(--cond);font-size:15px;white-space:nowrap">
            Rp <?= number_format($row['grand_total'], 0, ',', '.') ?>
          </td>
          <td style="font-size:12px;color:var(--text3);white-space:nowrap">
            <?= date('d M Y', strtotime($row['created_at'])) ?><br>
            <span style="font-family:var(--mono)"><?= date('H:i:s', strtotime($row['created_at'])) ?></span>
          </td>
          <td style="white-space:nowrap">
            <div class="flex gap-8">
              <button class="btn btn-secondary btn-sm" onclick="viewDetail(<?= $row['id'] ?>, <?= htmlspecialchars(json_encode($row), ENT_QUOTES) ?>)">
                <i class="fa fa-eye"></i>
              </button>
              <a href="<?= BASE_URL ?>/pages/receipt_pdf.php?trx=<?= $row['id'] ?>" target="_blank" class="btn btn-primary btn-sm">
                <i class="fa fa-print"></i>
              </a>
            </div>
          </td>
        </tr>
        <?php endwhile; endif; ?>
      </tbody>
    </table>
  </div>
  <?php if ($total_pages > 1): ?>
  <div class="pagination">
    <?php if ($pg > 1): ?><a href="?page=<?= $pg-1 ?>&<?= $q_params ?>" class="page-btn">‹</a><?php endif; ?>
    <?php for ($i = max(1,$pg-2); $i <= min($total_pages,$pg+2); $i++): ?>
    <a href="?page=<?= $i ?>&<?= $q_params ?>" class="page-btn <?= $i==$pg?'active':'' ?>"><?= $i ?></a>
    <?php endfor; ?>
    <?php if ($pg < $total_pages): ?><a href="?page=<?= $pg+1 ?>&<?= $q_params ?>" class="page-btn">›</a><?php endif; ?>
    <span style="margin-left:8px;font-size:12px;color:var(--text3)">Total <?= $total_count ?> transaksi</span>
  </div>
  <?php endif; ?>
</div>

<!-- Detail Modal -->
<div class="modal-overlay" id="detailModal">
  <div class="modal" style="max-width:520px">
    <div class="modal-header">
      <div class="modal-title">Detail Transaksi</div>
      <button class="modal-close" onclick="closeModal('detailModal')">✕</button>
    </div>
    <div class="modal-body" id="detailBody"></div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="closeModal('detailModal')">Tutup</button>
      <a id="printLink" href="#" target="_blank" class="btn btn-primary"><i class="fa fa-print"></i> Print Struk</a>
    </div>
  </div>
</div>

<script>
function viewDetail(id, row) {
  const prods = JSON.parse(row.products);
  document.getElementById('printLink').href = '<?= BASE_URL ?>/pages/receipt_pdf.php?trx=' + id;
  let html = `<div style="margin-bottom:14px">
    <span class="badge badge-blue" style="font-size:12px;padding:3px 10px">${row.kode}</span>
    <div style="font-size:12px;color:var(--text3);margin-top:8px">
      <i class="fa fa-user"></i> ${row.cashier_name} &nbsp;|&nbsp;
      <i class="fa fa-clock"></i> ${row.created_at}
    </div>
  </div>
  <div class="table-wrap" style="margin-bottom:14px">
    <table><thead><tr><th>Produk</th><th>SKU</th><th>Qty</th><th>Harga</th><th>Subtotal</th></tr></thead><tbody>`;
  prods.forEach(p => {
    const final = p.final || p.final_price || p.price;
    const line = final * p.qty;
    html += `<tr>
      <td style="color:var(--text);font-weight:600">${p.name}</td>
      <td class="td-mono" style="font-size:10px">${p.sku}</td>
      <td>${p.qty}</td>
      <td>Rp ${Math.round(final).toLocaleString('id-ID')}${p.discount>0?'<br><span style="font-size:10px;color:var(--red)">-'+p.discount+'%</span>':''}</td>
      <td style="color:var(--green);font-weight:600">Rp ${Math.round(line).toLocaleString('id-ID')}</td>
    </tr>`;
  });
  html += `</tbody></table></div>
  <div style="border-top:1px solid var(--border);padding-top:10px;display:flex;justify-content:space-between;align-items:center">
    <span style="font-family:var(--cond);font-size:16px;font-weight:700">GRAND TOTAL</span>
    <span style="font-family:var(--cond);font-size:22px;font-weight:700;color:var(--accent)">Rp ${parseFloat(row.grand_total).toLocaleString('id-ID')}</span>
  </div>`;
  document.getElementById('detailBody').innerHTML = html;
  openModal('detailModal');
}
</script>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
