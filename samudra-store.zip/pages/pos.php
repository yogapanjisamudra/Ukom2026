<?php
require_once dirname(__DIR__) . '/config.php';
require_login();

$conn = db();
$cashier = current_cashier();

// Init cart in session
if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];

// ── ALL CART + CHECKOUT ACTIONS BEFORE OUTPUT ──
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // Add item to cart
    if ($action === 'cart_add') {
        $pid = (int)($_POST['product_id'] ?? 0);
        $res = mysqli_query($conn, "SELECT p.*, c.alias as cat_alias FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.id=$pid LIMIT 1");
        $prod = mysqli_fetch_assoc($res);
        if ($prod && $prod['stock'] > 0) {
            if (isset($_SESSION['cart'][$pid])) {
                if ($_SESSION['cart'][$pid]['qty'] < $prod['stock']) {
                    $_SESSION['cart'][$pid]['qty']++;
                }
            } else {
                $final = $prod['discount'] > 0 ? $prod['price'] * (1 - $prod['discount'] / 100) : $prod['price'];
                $_SESSION['cart'][$pid] = [
                    'id'       => $prod['id'],
                    'name'     => $prod['name'],
                    'sku'      => $prod['sku'],
                    'price'    => (float)$prod['price'],
                    'discount' => (float)$prod['discount'],
                    'final'    => $final,
                    'stock'    => (int)$prod['stock'],
                    'qty'      => 1,
                ];
            }
        }
        header('Location: ' . BASE_URL . '/pages/pos.php');
        exit;
    }

    // Add by SKU input
    if ($action === 'cart_add_sku') {
        $sku = strtoupper(trim($_POST['sku'] ?? ''));
        if ($sku) {
            $s = sanitize($sku);
            $res = mysqli_query($conn, "SELECT p.*, c.alias FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE UPPER(p.sku)='$s' LIMIT 1");
            $prod = mysqli_fetch_assoc($res);
            if (!$prod) {
                $_SESSION['sku_error'] = "SKU \"$sku\" tidak ditemukan.";
            } elseif ($prod['stock'] <= 0) {
                $_SESSION['sku_error'] = "Stok \"" . $prod['name'] . "\" habis.";
            } else {
                unset($_SESSION['sku_error']);
                $pid = $prod['id'];
                if (isset($_SESSION['cart'][$pid])) {
                    if ($_SESSION['cart'][$pid]['qty'] < $prod['stock']) {
                        $_SESSION['cart'][$pid]['qty']++;
                    }
                } else {
                    $final = $prod['discount'] > 0 ? $prod['price'] * (1 - $prod['discount'] / 100) : $prod['price'];
                    $_SESSION['cart'][$pid] = [
                        'id' => $prod['id'], 'name' => $prod['name'], 'sku' => $prod['sku'],
                        'price' => (float)$prod['price'], 'discount' => (float)$prod['discount'],
                        'final' => $final, 'stock' => (int)$prod['stock'], 'qty' => 1,
                    ];
                }
            }
        }
        header('Location: ' . BASE_URL . '/pages/pos.php');
        exit;
    }

    // Change qty (+/-)
    if ($action === 'cart_qty') {
        $pid = (int)($_POST['product_id'] ?? 0);
        $delta = (int)($_POST['delta'] ?? 0);
        if (isset($_SESSION['cart'][$pid])) {
            $new_qty = $_SESSION['cart'][$pid]['qty'] + $delta;
            $stock = $_SESSION['cart'][$pid]['stock'];
            if ($new_qty <= 0) {
                unset($_SESSION['cart'][$pid]);
            } elseif ($new_qty <= $stock) {
                $_SESSION['cart'][$pid]['qty'] = $new_qty;
            }
        }
        header('Location: ' . BASE_URL . '/pages/pos.php');
        exit;
    }

    // Remove item
    if ($action === 'cart_remove') {
        $pid = (int)($_POST['product_id'] ?? 0);
        unset($_SESSION['cart'][$pid]);
        header('Location: ' . BASE_URL . '/pages/pos.php');
        exit;
    }

    // Clear cart
    if ($action === 'cart_clear') {
        $_SESSION['cart'] = [];
        header('Location: ' . BASE_URL . '/pages/pos.php');
        exit;
    }

    // Checkout
    if ($action === 'checkout') {
        $paid = (float)($_POST['paid'] ?? 0);
        $cart = $_SESSION['cart'];

        if (empty($cart)) {
            set_flash('error', 'Keranjang kosong.');
            header('Location: ' . BASE_URL . '/pages/pos.php');
            exit;
        }

        // Recalculate total server-side
        $grand_total = 0;
        foreach ($cart as $item) {
            $grand_total += $item['final'] * $item['qty'];
        }

        if ($paid < $grand_total) {
            set_flash('error', 'Uang bayar kurang dari total.');
            header('Location: ' . BASE_URL . '/pages/pos.php');
            exit;
        }

        $kode = gen_trx_code();
        $cashier_id = (int)$cashier['id'];
        $items_safe = sanitize(json_encode(array_values($cart)));

        mysqli_begin_transaction($conn);
        try {
            mysqli_query($conn, "INSERT INTO transactions (kode, cashier_id, grand_total, products) VALUES ('$kode', $cashier_id, $grand_total, '$items_safe')");
            $trx_id = mysqli_insert_id($conn);
            foreach ($cart as $item) {
                $pid = (int)$item['id'];
                $qty = (int)$item['qty'];
                mysqli_query($conn, "UPDATE products SET stock = stock - $qty, sold = sold + $qty WHERE id=$pid AND stock >= $qty");
                if (mysqli_affected_rows($conn) === 0) {
                    throw new Exception("Stok tidak cukup: " . $item['name']);
                }
            }
            mysqli_commit($conn);

            $_SESSION['last_trx'] = [
                'id' => $trx_id, 'kode' => $kode,
                'items' => array_values($cart),
                'grand_total' => $grand_total,
                'paid' => $paid,
                'change' => $paid - $grand_total,
                'cashier' => $cashier['username'],
                'time' => date('Y-m-d H:i:s'),
            ];
            $_SESSION['cart'] = [];

            header('Location: ' . BASE_URL . '/pages/pos.php?success=1&trx=' . $trx_id);
            exit;
        } catch (Exception $ex) {
            mysqli_rollback($conn);
            set_flash('error', $ex->getMessage());
            header('Location: ' . BASE_URL . '/pages/pos.php');
            exit;
        }
    }
}

// ── BUILD VIEW DATA ──
$cart = $_SESSION['cart'];
$sku_error = $_SESSION['sku_error'] ?? '';
unset($_SESSION['sku_error']);

// Cart totals
$subtotal = 0;
$total_discount = 0;
foreach ($cart as $item) {
    $subtotal += $item['price'] * $item['qty'];
    $total_discount += $item['price'] * ($item['discount'] / 100) * $item['qty'];
}
$grand_total = $subtotal - $total_discount;

// Products for grid
$products_raw = mysqli_query($conn, "SELECT p.*, c.nama as cat_name FROM products p LEFT JOIN categories c ON c.id=p.category_id ORDER BY c.nama ASC, p.name ASC");
$all_products = [];
while ($row = mysqli_fetch_assoc($products_raw)) $all_products[] = $row;

$cats_raw = mysqli_query($conn, "SELECT * FROM categories ORDER BY nama ASC");
$all_cats = [['id' => 0, 'nama' => 'Semua']];
while ($c = mysqli_fetch_assoc($cats_raw)) $all_cats[] = $c;

// Receipt data
$success  = isset($_GET['success']) && isset($_SESSION['last_trx']);
$last_trx = $success ? $_SESSION['last_trx'] : null;
if ($success) unset($_SESSION['last_trx']);

$page_title = 'Kasir (POS)';
require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="pos-layout">

  <!-- ── LEFT: Products ── -->
  <div class="pos-left">

    <!-- SKU input + Search -->
    <div class="card" style="padding:14px 16px">
      <div class="pos-input-row">
        <div>
          <div class="pos-section-label">INPUT SKU</div>
          <form method="POST" class="flex gap-8" id="skuForm">
            <input type="hidden" name="action" value="cart_add_sku">
            <input type="text" name="sku" id="skuInput" class="form-control"
              placeholder="Scan / ketik SKU..." autocomplete="off"
              style="font-family:var(--mono);letter-spacing:1px" autofocus>
            <button type="submit" class="btn btn-primary">
              <i class="fa fa-barcode"></i> Add
            </button>
          </form>
          <?php if ($sku_error): ?>
          <div style="color:var(--red);font-size:12px;margin-top:4px">
            <i class="fa fa-circle-exclamation"></i> <?= e($sku_error) ?>
          </div>
          <?php endif; ?>
        </div>
        <div>
          <div class="pos-section-label">CARI PRODUK</div>
          <div class="search-input-wrap">
            <span class="icon"><i class="fa fa-search"></i></span>
            <input type="text" id="productSearch" class="form-control search-input"
              placeholder="Cari nama produk..." oninput="filterProducts()" autocomplete="off">
          </div>
        </div>
      </div>
      <!-- Category tabs -->
      <div style="display:flex;gap:6px;margin-top:10px;flex-wrap:wrap" id="catTabs">
        <?php foreach ($all_cats as $c): ?>
        <button class="btn btn-sm <?= $c['id'] == 0 ? 'btn-primary' : 'btn-secondary' ?>"
          data-cat="<?= $c['id'] ?>" onclick="filterByCategory(this, <?= $c['id'] ?>)">
          <?= e($c['nama']) ?>
        </button>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Product Grid -->
    <div class="pos-products">
      <div class="products-grid" id="productsGrid">
        <?php foreach ($all_products as $p):
          $fp = $p['discount'] > 0 ? $p['price'] * (1 - $p['discount'] / 100) : $p['price'];
          $in_cart = isset($cart[$p['id']]);
        ?>
        <form method="POST" class="product-tile-form" data-cat="<?= $p['category_id'] ?>"
          data-name="<?= e(strtolower($p['name'])) ?>" data-sku="<?= e(strtolower($p['sku'])) ?>">
          <input type="hidden" name="action" value="cart_add">
          <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
          <button type="submit" class="product-tile <?= $p['stock'] == 0 ? 'out-of-stock' : '' ?>"
            <?= $p['stock'] == 0 ? 'disabled' : '' ?>>
            <?php if ($p['discount'] > 0): ?>
            <span class="product-tile-discount">-<?= $p['discount'] ?>%</span>
            <?php endif; ?>
            <?php if ($in_cart): ?>
            <span class="product-tile-in-cart"><i class="fa fa-check"></i> <?= $cart[$p['id']]['qty'] ?>x</span>
            <?php endif; ?>
            <div class="product-tile-name"><?= e($p['name']) ?></div>
            <div class="product-tile-sku"><?= e($p['sku']) ?></div>
            <div class="product-tile-price">Rp <?= number_format($fp, 0, ',', '.') ?></div>
            <?php if ($p['discount'] > 0): ?>
            <div style="font-size:10px;color:var(--text3);text-decoration:line-through">Rp <?= number_format($p['price'], 0, ',', '.') ?></div>
            <?php endif; ?>
            <div class="product-tile-stock" style="color:<?= $p['stock']==0?'var(--red)':($p['stock']<=5?'var(--yellow)':'var(--text3)') ?>">
              <?= $p['stock'] == 0 ? 'Habis' : 'Stok: ' . $p['stock'] ?>
            </div>
          </button>
        </form>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <!-- ── RIGHT: Cart ── -->
  <div class="pos-right">
    <div class="cart-header">
      <div class="cart-title"><i class="fa fa-shopping-cart"></i> Keranjang</div>
      <div class="flex gap-8" style="align-items:center">
        <span class="cart-count"><?= count($cart) ?> item</span>
        <?php if (!empty($cart)): ?>
        <form method="POST" style="display:inline">
          <input type="hidden" name="action" value="cart_clear">
          <button type="submit" class="btn btn-ghost btn-sm btn-icon" title="Kosongkan keranjang"
            onclick="return confirm('Kosongkan semua keranjang?')">
            <i class="fa fa-broom"></i>
          </button>
        </form>
        <?php endif; ?>
      </div>
    </div>

    <!-- Cart Items -->
    <div class="cart-items">
      <?php if (empty($cart)): ?>
      <div class="cart-empty">
        <span class="icon">🛒</span>
        <span>Keranjang masih kosong</span>
        <span style="font-size:11px;color:var(--text3)">Klik produk atau scan SKU</span>
      </div>
      <?php else: foreach ($cart as $item):
        $line = $item['final'] * $item['qty'];
      ?>
      <div class="cart-item">
        <div class="cart-item-info">
          <div class="cart-item-name"><?= e($item['name']) ?></div>
          <div class="cart-item-sku"><?= e($item['sku']) ?></div>
          <div class="cart-item-price">Rp <?= number_format($line, 0, ',', '.') ?></div>
          <div class="cart-item-qty">
            <!-- Minus -->
            <form method="POST" style="display:inline">
              <input type="hidden" name="action" value="cart_qty">
              <input type="hidden" name="product_id" value="<?= $item['id'] ?>">
              <input type="hidden" name="delta" value="-1">
              <button type="submit" class="qty-btn">−</button>
            </form>
            <span class="qty-num"><?= $item['qty'] ?></span>
            <!-- Plus -->
            <form method="POST" style="display:inline">
              <input type="hidden" name="action" value="cart_qty">
              <input type="hidden" name="product_id" value="<?= $item['id'] ?>">
              <input type="hidden" name="delta" value="1">
              <button type="submit" class="qty-btn" <?= $item['qty'] >= $item['stock'] ? 'disabled style="opacity:0.3"' : '' ?>>+</button>
            </form>
            <span style="font-size:10px;color:var(--text3)">
              × Rp <?= number_format($item['final'], 0, ',', '.') ?>
            </span>
          </div>
        </div>
        <!-- Remove -->
        <form method="POST" style="display:inline">
          <input type="hidden" name="action" value="cart_remove">
          <input type="hidden" name="product_id" value="<?= $item['id'] ?>">
          <button type="submit" class="cart-item-remove" title="Hapus item">✕</button>
        </form>
      </div>
      <?php endforeach; endif; ?>
    </div>

    <!-- Cart Footer -->
    <div class="cart-footer">
      <div class="cart-subtotals">
        <div class="cart-row">
          <span>Subtotal</span>
          <span>Rp <?= number_format($subtotal, 0, ',', '.') ?></span>
        </div>
        <div class="cart-row">
          <span>Total Diskon</span>
          <span style="color:var(--red)">- Rp <?= number_format($total_discount, 0, ',', '.') ?></span>
        </div>
        <div class="cart-row total">
          <span>TOTAL</span>
          <span class="amount">Rp <?= number_format($grand_total, 0, ',', '.') ?></span>
        </div>
      </div>

      <?php if (!empty($cart)): ?>
      <div class="cart-pay">
        <div class="pay-input-wrap">
          <div style="flex:1">
            <div style="font-family:var(--mono);font-size:9px;color:var(--text3);margin-bottom:4px;letter-spacing:1px">UANG BAYAR</div>
            <input type="number" id="paidInput" class="form-control" placeholder="0" min="0"
              oninput="calcChange(<?= $grand_total ?>)" value="">
          </div>
          <div style="display:flex;flex-direction:column;justify-content:flex-end">
            <button class="btn btn-secondary btn-sm" onclick="setExact(<?= $grand_total ?>)">Pas</button>
          </div>
        </div>
        <div class="change-display" id="changeDisplay">
          <span class="label">Kembalian</span>
          <span class="amount" id="changeDisp">Rp 0</span>
        </div>
        <button class="btn btn-success btn-lg w-full" onclick="openCheckoutModal(<?= $grand_total ?>)">
          <i class="fa fa-check-circle"></i> Bayar Sekarang
        </button>
      </div>
      <?php else: ?>
      <div style="padding:12px 0">
        <button class="btn btn-success btn-lg w-full" disabled style="opacity:0.4">
          <i class="fa fa-check-circle"></i> Bayar Sekarang
        </button>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- ── Checkout Modal ── -->
<div class="modal-overlay" id="checkoutModal">
  <div class="modal">
    <div class="modal-header">
      <div class="modal-title">Konfirmasi Pembayaran</div>
      <button class="modal-close" onclick="closeModal('checkoutModal')">✕</button>
    </div>
    <div class="modal-body">
      <div class="table-wrap" style="margin-bottom:14px">
        <table>
          <thead><tr><th>Produk</th><th>Qty</th><th>Subtotal</th></tr></thead>
          <tbody>
            <?php foreach ($cart as $item): ?>
            <tr>
              <td style="color:var(--text);font-weight:600"><?= e($item['name']) ?>
                <?php if ($item['discount'] > 0): ?>
                <span class="badge badge-red" style="font-size:9px"><?= $item['discount'] ?>% OFF</span>
                <?php endif; ?>
              </td>
              <td><?= $item['qty'] ?></td>
              <td style="color:var(--green);font-weight:600">Rp <?= number_format($item['final'] * $item['qty'], 0, ',', '.') ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <div style="border-top:1px solid var(--border);padding-top:12px">
        <div class="cart-row" style="font-size:13px">
          <span>Grand Total</span>
          <span style="color:var(--accent);font-weight:700;font-size:20px">Rp <?= number_format($grand_total, 0, ',', '.') ?></span>
        </div>
        <div class="cart-row" style="font-size:13px;margin-top:6px">
          <span>Dibayar</span>
          <span id="modalPaidDisp" style="color:var(--green);font-weight:600">Rp 0</span>
        </div>
        <div class="cart-row" style="font-size:13px">
          <span>Kembalian</span>
          <span id="modalChangeDisp" style="color:var(--yellow);font-weight:600">Rp 0</span>
        </div>
      </div>
    </div>
    <form method="POST" id="checkoutForm">
      <input type="hidden" name="action" value="checkout">
      <input type="hidden" name="paid" id="formPaid" value="0">
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('checkoutModal')">Batal</button>
        <button type="submit" class="btn btn-success" id="checkoutSubmitBtn">
          <i class="fa fa-check"></i> Konfirmasi & Bayar
        </button>
      </div>
    </form>
  </div>
</div>

<!-- ── Receipt Modal (shown after success) ── -->
<?php if ($success && $last_trx): ?>
<div class="modal-overlay open" id="receiptModal">
  <div class="modal" style="max-width:380px">
    <div class="modal-header">
      <div class="modal-title" style="color:var(--green)">
        <i class="fa fa-check-circle"></i> Transaksi Berhasil!
      </div>
      <button class="modal-close" onclick="closeModal('receiptModal')">✕</button>
    </div>
    <div class="modal-body">
      <div style="text-align:center;margin-bottom:16px">
        <span class="badge badge-green" style="font-size:13px;padding:4px 12px"><?= e($last_trx['kode']) ?></span>
      </div>
      <div id="receiptContent">
        <?php include dirname(__DIR__) . '/includes/receipt_template.php'; ?>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="closeModal('receiptModal')">Tutup</button>
      <button class="btn btn-primary" onclick="printReceipt()"><i class="fa fa-print"></i> Print</button>
      <a href="<?= BASE_URL ?>/pages/receipt_pdf.php?trx=<?= $last_trx['id'] ?>" class="btn btn-success" target="_blank">
        <i class="fa fa-file-pdf"></i> PDF
      </a>
    </div>
  </div>
</div>
<?php endif; ?>

<script>
// Filter products by search
var activeCat = 0;
function filterProducts() {
  var q = document.getElementById('productSearch').value.toLowerCase();
  var forms = document.querySelectorAll('.product-tile-form');
  for (var i = 0; i < forms.length; i++) {
    var f = forms[i];
    var inSearch = f.dataset.name.indexOf(q) !== -1 || f.dataset.sku.indexOf(q) !== -1;
    var inCat = activeCat === 0 || parseInt(f.dataset.cat) === activeCat;
    f.style.display = (inSearch && inCat) ? '' : 'none';
  }
}

function filterByCategory(btn, catId) {
  activeCat = catId;
  var btns = document.querySelectorAll('#catTabs button');
  for (var i = 0; i < btns.length; i++) {
    var b = btns[i];
    b.className = 'btn btn-sm ' + (parseInt(b.dataset.cat) === catId ? 'btn-primary' : 'btn-secondary');
  }
  filterProducts();
}

// Payment calc
function calcChange(total) {
  var paid = parseFloat(document.getElementById('paidInput').value) || 0;
  var change = paid - total;
  var disp = document.getElementById('changeDisp');
  var box = document.getElementById('changeDisplay');
  if (change < 0) {
    box.classList.add('negative');
    disp.textContent = '- Rp ' + Math.abs(Math.round(change)).toLocaleString('id-ID');
  } else {
    box.classList.remove('negative');
    disp.textContent = 'Rp ' + Math.round(change).toLocaleString('id-ID');
  }
}

function setExact(total) {
  document.getElementById('paidInput').value = Math.ceil(total);
  calcChange(total);
}

function openCheckoutModal(total) {
  var paid = parseFloat(document.getElementById('paidInput').value) || 0;
  if (paid < total) {
    alert('Uang bayar kurang dari total! Total: Rp ' + Math.round(total).toLocaleString('id-ID'));
    return;
  }
  var change = paid - total;
  document.getElementById('modalPaidDisp').textContent = 'Rp ' + Math.round(paid).toLocaleString('id-ID');
  document.getElementById('modalChangeDisp').textContent = 'Rp ' + Math.round(change).toLocaleString('id-ID');
  document.getElementById('formPaid').value = paid;
  openModal('checkoutModal');
}

function printReceipt() {
  var content = document.getElementById('receiptContent').innerHTML;
  var w = window.open('', '_blank', 'width=400,height=600');
  w.document.write('<html><head><title>Struk</title><style>body{font-family:monospace;padding:20px;margin:0}</style></head><body>' + content + '</body></html>');
  w.document.close();
  setTimeout(function(){ w.focus(); w.print(); }, 300);
}
</script>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
