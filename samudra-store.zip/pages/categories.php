<?php
require_once dirname(__DIR__) . '/config.php';
require_login();

$conn = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $nama = trim($_POST['nama'] ?? '');
        $alias = strtoupper(trim($_POST['alias'] ?? ''));
        if (!$nama || !$alias) {
            set_flash('error', 'Nama dan alias wajib diisi.');
        } elseif (strlen($alias) !== 3 || !ctype_alpha($alias)) {
            set_flash('error', 'Alias harus tepat 3 huruf.');
        } else {
            $n = sanitize($nama); $a = sanitize($alias);
            $res = mysqli_query($conn, "SELECT id FROM categories WHERE alias='$a' LIMIT 1");
            if (mysqli_num_rows($res) > 0) {
                set_flash('error', 'Alias sudah digunakan.');
            } else {
                mysqli_query($conn, "INSERT INTO categories (nama, alias) VALUES ('$n','$a')");
                set_flash('success', 'Kategori berhasil ditambahkan.');
            }
        }
    }

    if ($action === 'edit') {
        $id = (int)$_POST['id'];
        $nama = trim($_POST['nama'] ?? '');
        $alias = strtoupper(trim($_POST['alias'] ?? ''));
        if (!$nama || !$alias) {
            set_flash('error', 'Nama dan alias wajib diisi.');
        } elseif (strlen($alias) !== 3 || !ctype_alpha($alias)) {
            set_flash('error', 'Alias harus tepat 3 huruf.');
        } else {
            $n = sanitize($nama); $a = sanitize($alias);
            $check = mysqli_query($conn, "SELECT id FROM categories WHERE alias='$a' AND id != $id LIMIT 1");
            if (mysqli_num_rows($check) > 0) {
                set_flash('error', 'Alias sudah digunakan kategori lain.');
            } else {
                mysqli_query($conn, "UPDATE categories SET nama='$n', alias='$a' WHERE id=$id");
                set_flash('success', 'Kategori berhasil diupdate.');
            }
        }
    }

    if ($action === 'delete') {
        $id = (int)$_POST['id'];
        $check = mysqli_query($conn, "SELECT id FROM products WHERE category_id=$id LIMIT 1");
        if (mysqli_num_rows($check) > 0) {
            set_flash('error', 'Tidak bisa hapus, kategori masih digunakan produk.');
        } else {
            mysqli_query($conn, "DELETE FROM categories WHERE id=$id");
            set_flash('success', 'Kategori berhasil dihapus.');
        }
    }

    header('Location: ' . BASE_URL . '/pages/categories.php');
    exit;
}

$categories = mysqli_query($conn, "
    SELECT c.*, COUNT(p.id) as product_count
    FROM categories c
    LEFT JOIN products p ON p.category_id = c.id
    GROUP BY c.id
    ORDER BY c.nama ASC
");

$page_title = 'Kategori';
require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="card">
  <div class="card-header">
    <div class="card-title"><i class="fa fa-tag"></i> Daftar Kategori</div>
    <button class="btn btn-primary btn-sm" onclick="openModal('addModal')">
      <i class="fa fa-plus"></i> Tambah Kategori
    </button>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr><th>#</th><th>Nama Kategori</th><th>Alias (SKU)</th><th>Jumlah Produk</th><th>Dibuat</th><th>Aksi</th></tr>
      </thead>
      <tbody>
        <?php $no = 1; while ($row = mysqli_fetch_assoc($categories)): ?>
        <tr>
          <td class="text-muted"><?= $no++ ?></td>
          <td style="font-weight:600;color:var(--text)"><?= e($row['nama']) ?></td>
          <td><span class="badge badge-blue"><?= e($row['alias']) ?></span></td>
          <td>
            <?php if ($row['product_count'] > 0): ?>
              <span class="badge badge-green"><?= $row['product_count'] ?> produk</span>
            <?php else: ?>
              <span class="badge badge-gray">0 produk</span>
            <?php endif; ?>
          </td>
          <td class="text-muted" style="font-size:12px"><?= date('d M Y', strtotime($row['created_at'])) ?></td>
          <td>
            <div class="flex gap-8">
              <button class="btn btn-secondary btn-sm"
                onclick="editCategory(<?= $row['id'] ?>, '<?= e(addslashes($row['nama'])) ?>', '<?= e($row['alias']) ?>')">
                <i class="fa fa-pen"></i>
              </button>
              <?php if ($row['product_count'] == 0): ?>
              <button class="btn btn-danger btn-sm"
                onclick="deleteCategory(<?= $row['id'] ?>, '<?= e(addslashes($row['nama'])) ?>')">
                <i class="fa fa-trash"></i>
              </button>
              <?php else: ?>
              <button class="btn btn-ghost btn-sm" disabled style="opacity:0.3" title="Ada produk terkait"><i class="fa fa-trash"></i></button>
              <?php endif; ?>
            </div>
          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Add Modal -->
<div class="modal-overlay" id="addModal">
  <div class="modal">
    <div class="modal-header">
      <div class="modal-title">Tambah Kategori</div>
      <button class="modal-close" onclick="closeModal('addModal')">✕</button>
    </div>
    <form method="POST">
      <input type="hidden" name="action" value="add">
      <div class="modal-body">
        <div class="form-group">
          <label class="form-label">Nama Kategori</label>
          <input type="text" name="nama" class="form-control" placeholder="Contoh: Minuman" required autofocus>
        </div>
        <div class="form-group">
          <label class="form-label">Alias (3 huruf untuk SKU)</label>
          <input type="text" name="alias" class="form-control" placeholder="Contoh: MNM" maxlength="3" required
            oninput="this.value=this.value.toUpperCase().replace(/[^A-Z]/g,'')">
          <div style="font-size:11px;color:var(--text3);margin-top:4px">Digunakan sebagai prefix SKU produk.</div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('addModal')">Batal</button>
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
    </form>
  </div>
</div>

<!-- Edit Modal -->
<div class="modal-overlay" id="editModal">
  <div class="modal">
    <div class="modal-header">
      <div class="modal-title">Edit Kategori</div>
      <button class="modal-close" onclick="closeModal('editModal')">✕</button>
    </div>
    <form method="POST">
      <input type="hidden" name="action" value="edit">
      <input type="hidden" name="id" id="edit_id">
      <div class="modal-body">
        <div class="form-group">
          <label class="form-label">Nama Kategori</label>
          <input type="text" name="nama" id="edit_nama" class="form-control" required>
        </div>
        <div class="form-group">
          <label class="form-label">Alias (3 huruf)</label>
          <input type="text" name="alias" id="edit_alias" class="form-control" maxlength="3" required
            oninput="this.value=this.value.toUpperCase().replace(/[^A-Z]/g,'')">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('editModal')">Batal</button>
        <button type="submit" class="btn btn-primary">Update</button>
      </div>
    </form>
  </div>
</div>

<form method="POST" id="deleteForm" style="display:none">
  <input type="hidden" name="action" value="delete">
  <input type="hidden" name="id" id="delete_id">
</form>

<script>
function editCategory(id, nama, alias) {
  document.getElementById('edit_id').value = id;
  document.getElementById('edit_nama').value = nama;
  document.getElementById('edit_alias').value = alias;
  openModal('editModal');
}
function deleteCategory(id, nama) {
  showConfirm('Hapus Kategori', 'Hapus kategori "' + nama + '"?', '🗑️', function() {
    document.getElementById('delete_id').value = id;
    document.getElementById('deleteForm').submit();
  });
}
</script>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
