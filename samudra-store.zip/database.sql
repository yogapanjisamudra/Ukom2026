-- Samudra Store Database
CREATE DATABASE IF NOT EXISTS samudra_store_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE samudra_store_db;

CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    alias CHAR(3) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS cashiers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(80) NOT NULL UNIQUE,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    sku VARCHAR(50) NOT NULL UNIQUE,
    category_id INT NOT NULL,
    berat INT NOT NULL DEFAULT 0 COMMENT 'gram',
    price DECIMAL(12,2) NOT NULL DEFAULT 0,
    discount DECIMAL(5,2) NOT NULL DEFAULT 0 COMMENT 'percent',
    stock INT NOT NULL DEFAULT 0,
    sold INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    kode VARCHAR(30) NOT NULL UNIQUE,
    cashier_id INT NOT NULL,
    grand_total DECIMAL(14,2) NOT NULL DEFAULT 0,
    products JSON NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (cashier_id) REFERENCES cashiers(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- ── CASHIERS ──
-- password = 'password' for all
INSERT INTO cashiers (username, email, password) VALUES
('admin',   'admin@samudrastore.id',  '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
('budi',    'budi@samudrastore.id',   '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
('siti',    'siti@samudrastore.id',   '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
('rendi',   'rendi@samudrastore.id',  '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi')
ON DUPLICATE KEY UPDATE id=id;

-- ── CATEGORIES ──
INSERT INTO categories (nama, alias) VALUES
('Minuman',    'MNM'),
('Makanan',    'MKN'),
('Snack',      'SNK'),
('Kebersihan', 'KBR'),
('Rokok',      'RKK'),
('Sembako',    'SMB'),
('Es & Frozen','ESF'),
('Bumbu',      'BMB'),
('Kesehatan',  'KSH'),
('Alat Tulis', 'ATK')
ON DUPLICATE KEY UPDATE id=id;

-- ── PRODUCTS ──
-- Minuman (cat 1)
INSERT INTO products (name, sku, category_id, berat, price, discount, stock, sold) VALUES
('Aqua Botol 600ml',         'MNM-AQUA-600',   1,  600,  3500,  0,   120, 340),
('Aqua Galon 19L',           'MNM-AQUA-19000', 1,19000, 22000,  0,    18,  62),
('Teh Botol Sosro 350ml',    'MNM-TEHS-350',   1,  350,  4000,  0,    95, 210),
('Le Minerale 600ml',        'MNM-LEMI-600',   1,  600,  3500,  0,    80, 175),
('Pocari Sweat 500ml',       'MNM-POCA-500',   1,  500,  8000,  5,    45,  98),
('Mizone Apel 500ml',        'MNM-MIZO-500',   1,  500,  7000,  0,    50,  87),
('Coca Cola Can 330ml',      'MNM-COKE-330',   1,  330,  8500,  0,    40, 130),
('Sprite Can 330ml',         'MNM-SPRT-330',   1,  330,  8500,  0,    35,  95),
('Fanta Strawberry 330ml',   'MNM-FANT-330',   1,  330,  8500,  0,    30,  80),
('Good Day Kopi Susu 250ml', 'MNM-GOOD-250',   1,  250,  5000,  0,    60, 145),
('Susu Ultramilk Full Cream 250ml', 'MNM-ULTR-250', 1, 250, 5500, 0,  55, 110),
('Yakult 5-pack',            'MNM-YAKL-65',    1,  325, 15000, 10,    40,  88),
('Nu Green Tea 330ml',       'MNM-NUGT-330',   1,  330,  5000,  0,    70, 120),
('Floridina Jeruk 350ml',    'MNM-FLOR-350',   1,  350,  4500,  0,    65, 105),
('Cap Panda Cincau 250ml',   'MNM-CAPP-250',   1,  250,  4000,  0,    50,  90),

-- Makanan (cat 2)
('Indomie Goreng Orig',      'MKN-INDM-85',    2,   85,  3000,  0,   200, 580),
('Indomie Kuah Ayam Bawang', 'MKN-INDM-70',    2,   70,  3000,  0,   180, 430),
('Pop Mie Ayam 75g',         'MKN-POPM-75',    2,   75,  5000,  0,    90, 210),
('Mie Sedaap Goreng',        'MKN-MIES-88',    2,   88,  2800,  0,   150, 320),
('Sarimi Soto Ayam',         'MKN-SARM-70',    2,   70,  2500,  0,   100, 195),
('Supermi Rasa Soto',        'MKN-SUPM-70',    2,   70,  2500,  0,    90, 175),
('Bimoli Minyak Goreng 1L',  'MKN-BIMO-1000',  2, 1000, 20000,  0,    30,  85),
('Royco Ayam 100g',          'MKN-ROYC-100',   2,  100,  5000,  0,    45,  95),
('Sarden ABC 155g',          'MKN-SABC-155',   2,  155, 13000,  0,    40,  78),
('Kornet Pronas 198g',       'MKN-KPRO-198',   2,  198, 16000,  5,    25,  55),

-- Snack (cat 3)
('Chitato Sapi Panggang 68g','SNK-CHIT-68',    3,   68,  9000,  0,    60, 185),
('Pringles Original 107g',   'SNK-PRIN-107',   3,  107, 35000, 10,    20,  48),
('Oreo Original 137g',       'SNK-OREO-137',   3,  137, 15000,  0,    50, 140),
('Silverqueen Cashew 62g',   'SNK-SILV-62',    3,   62, 16000,  0,    35,  90),
('Kit Kat 2F 35g',           'SNK-KITK-35',    3,   35,  8000,  0,    55, 120),
('Taro Net BBQ 65g',         'SNK-TARO-65',    3,   65,  8000,  0,    45, 100),
('Lays Rumput Laut 68g',     'SNK-LAYS-68',    3,   68,  9000,  0,    40,  95),
('Richeese Nabati 145g',     'SNK-RICH-145',   3,  145, 10000,  0,    60, 160),
('Qtela Singkong 130g',      'SNK-QTEL-130',   3,  130,  8000,  0,    55, 130),
('Beng-Beng Share It 160g',  'SNK-BENG-160',   3,  160, 12000,  0,    40,  88),
('Wafer Tango 160g',         'SNK-TANG-160',   3,  160, 10000,  0,    50, 105),
('Choki-Choki 12pcs',        'SNK-CHOK-60',    3,   60,  8000,  0,    70, 155),

-- Kebersihan (cat 4)
('Sabun Lifebuoy 85g',       'KBR-LIFE-85',    4,   85,  4500,  0,    60, 125),
('Shampo Pantene 170ml',     'KBR-PANT-170',   4,  170, 22000,  5,    30,  65),
('Odol Pepsodent 120g',      'KBR-PEPS-120',   4,  120,  9000,  0,    55, 120),
('Rinso Anti Noda 800g',     'KBR-RINS-800',   4,  800, 22000,  0,    25,  58),
('Sunlight Lime 800ml',      'KBR-SUNL-800',   4,  800, 18000,  0,    30,  70),
('Molto Pelembut 800ml',     'KBR-MOLT-800',   4,  800, 24000, 10,    20,  45),
('Dettol Antiseptik 60ml',   'KBR-DETT-60',    4,   60, 18000,  0,    35,  72),
('Tisu Paseo 250 lembar',    'KBR-TISU-250',   4,  250, 18000,  0,    40,  88),
('Pembalut Charm 16s',       'KBR-CHRM-80',    4,   80, 22000,  0,    25,  50),
('Kapas Johnsons 50g',       'KBR-JOHS-50',    4,   50,  8000,  0,    40,  75),

-- Rokok (cat 5)
('Gudang Garam Filter 12s',  'RKK-GGFL-24',    5,   24, 22000,  0,    50, 180),
('Sampoerna Mild 16s',       'RKK-SAMP-32',    5,   32, 28000,  0,    45, 165),
('Dji Sam Soe 12s',          'RKK-DJSS-30',    5,   30, 26000,  0,    40, 130),
('LA Lights 16s',            'RKK-LALT-32',    5,   32, 27000,  0,    35, 110),
('Marlboro Red 20s',         'RKK-MARLR-40',   5,   40, 32000,  0,    30,  95),
('Camel Filter 20s',         'RKK-CAML-40',    5,   40, 31000,  0,    25,  80),
('Dunhill Fine Cut 20s',     'RKK-DUNH-40',    5,   40, 33000,  0,    20,  65),
('Surya Pro Mild 16s',       'RKK-SURP-32',    5,   32, 26000,  0,    40, 100),

-- Sembako (cat 6)
('Beras Premium 5kg',        'SMB-BRAS-5000',  6, 5000, 72000,  0,    20,  55),
('Gula Pasir Gulaku 1kg',    'SMB-GULA-1000',  6, 1000, 16000,  0,    35,  90),
('Garam Kapal 250g',         'SMB-GRAM-250',   6,  250,  3000,  0,    60, 140),
('Tepung Terigu Segitiga 1kg','SMB-TPGT-1000', 6, 1000, 13000,  0,    30,  75),
('Telur Ayam 1kg',           'SMB-TLUR-1000',  6, 1000, 28000,  0,    25,  80),
('Kecap Bango 135ml',        'SMB-BCAP-135',   6,  135, 10000,  0,    50, 115),
('Kecap ABC Manis 275ml',    'SMB-ABCK-275',   6,  275, 14000,  0,    40,  95),
('Saus Sambal ABC 135ml',    'SMB-ABCS-135',   6,  135,  9000,  0,    55, 120),

-- Es & Frozen (cat 7)
('Es Krim Walls Magnum 80ml','ESF-WLMG-80',    7,   80, 15000, 10,    30,  78),
('Es Krim Campina 700ml',    'ESF-CAMP-700',   7,  700, 45000,  0,    12,  30),
('Aice Ice Cream Stick 65ml','ESF-AICE-65',    7,   65,  3000,  0,    60, 145),
('Sostel Sosis 200g',        'ESF-SOST-200',   7,  200, 18000,  0,    20,  48),
('Nugget Fiesta 500g',       'ESF-NUFI-500',   7,  500, 38000,  5,    15,  35),

-- Bumbu (cat 8)
('Royco Serbaguna 250g',     'BMB-ROYC-250',   8,  250, 12000,  0,    40,  88),
('Masako Ayam 100g',         'BMB-MSKA-100',   8,  100,  5500,  0,    55, 110),
('Kari Bamboe 50g',          'BMB-BAMB-50',    8,   50,  4000,  0,    45,  95),
('Soto Bamboe 50g',          'BMB-BAMS-50',    8,   50,  4000,  0,    40,  85),
('Ketumbar Bubuk Ladaku 40g','BMB-LADK-40',    8,   40,  5000,  0,    35,  70),
('Merica Lada Putih 50g',    'BMB-LPUT-50',    8,   50,  7000,  0,    30,  60),

-- Kesehatan (cat 9)
('Panadol 500mg Strip 10',   'KSH-PAND-10',    9,   10, 12000,  0,    40,  90),
('Bodrex Extra Strip 10',    'KSH-BODX-10',    9,   10,  8000,  0,    45,  95),
('Antangin JRG Sachet 3s',   'KSH-ANTJ-15',    9,   15,  8000,  0,    50, 110),
('Tolak Angin Sido Muncul 3s','KSH-TOLA-30',   9,   30, 10000,  0,    45, 100),
('Minyak Kayu Putih Cap Lang 30ml','KSH-CKPL-30', 9, 30, 20000, 0,   30,  65),
('Betadine 5ml',             'KSH-BETA-5',     9,    5, 12000,  0,    25,  55),
('Vitamin C Redoxon 10s',    'KSH-RDXN-10',    9,   30, 35000,  5,    20,  48),
('Oralit 200ml Sachet 5s',   'KSH-ORAL-5',     9,   30,  8000,  0,    35,  72),

-- Alat Tulis (cat 10)
('Pulpen Pilot G2 0.5',      'ATK-PLPG-10',   10,   10,  8000,  0,    40,  85),
('Pensil 2B Faber Castell',  'ATK-FABC-7',    10,    7,  4000,  0,    50, 110),
('Penghapus Staedtler',      'ATK-STAD-15',   10,   15,  5000,  0,    45,  90),
('Buku Tulis Sidu 38lbr',    'ATK-SIDU-100',  10,  100,  4500,  0,    60, 130),
('Spidol Snowman Hitam',     'ATK-SNOW-15',   10,   15,  8000,  0,    30,  65),
('Stabilo Boss 4 Warna',     'ATK-STAB-40',   10,   40, 25000,  0,    20,  45),
('Selotip Kenko 1"',         'ATK-KENK-40',   10,   40,  6000,  0,    35,  75),
('Gunting Joyko 6"',         'ATK-JOYK-80',   10,   80, 12000,  0,    20,  40)
ON DUPLICATE KEY UPDATE id=id;
