<?php
require_once dirname(__DIR__) . '/config.php';
require_login();
$cashier = current_cashier();
$current_page = basename($_SERVER['PHP_SELF'], '.php');
$nav_active = $current_page;
if ($current_page === 'index') $nav_active = 'dashboard';
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($page_title ?? 'Dashboard') ?> — <?= e(STORE_NAME) ?></title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout">

  <!-- Mobile sidebar overlay -->
  <div class="sidebar-overlay" id="sidebarOverlay" onclick="closeSidebar()"></div>

  <!-- SIDEBAR -->
  <aside class="sidebar" id="sidebar">
    <div class="sidebar-logo">
      <div class="store-name"><?= e(STORE_NAME) ?></div>
      <div class="store-loc"><i class="fa fa-location-dot"></i> <?= e(STORE_LOCATION) ?></div>
      <span class="tag">POS SYSTEM</span>
    </div>

    <nav class="nav">
      <div class="nav-section">Menu</div>
      <a href="<?= BASE_URL ?>/index.php" class="nav-item <?= $nav_active === 'dashboard' ? 'active' : '' ?>" onclick="closeSidebar()">
        <span class="icon"><i class="fa fa-gauge-high"></i></span> Dashboard
      </a>
      <a href="<?= BASE_URL ?>/pages/pos.php" class="nav-item <?= $nav_active === 'pos' ? 'active' : '' ?>" onclick="closeSidebar()">
        <span class="icon"><i class="fa fa-cash-register"></i></span> Kasir (POS)
      </a>

      <div class="nav-section">Kelola</div>
      <a href="<?= BASE_URL ?>/pages/products.php" class="nav-item <?= $nav_active === 'products' ? 'active' : '' ?>" onclick="closeSidebar()">
        <span class="icon"><i class="fa fa-box"></i></span> Produk
      </a>
      <a href="<?= BASE_URL ?>/pages/categories.php" class="nav-item <?= $nav_active === 'categories' ? 'active' : '' ?>" onclick="closeSidebar()">
        <span class="icon"><i class="fa fa-tag"></i></span> Kategori
      </a>
      <a href="<?= BASE_URL ?>/pages/transactions.php" class="nav-item <?= $nav_active === 'transactions' ? 'active' : '' ?>" onclick="closeSidebar()">
        <span class="icon"><i class="fa fa-receipt"></i></span> Riwayat Transaksi
      </a>
      <a href="<?= BASE_URL ?>/pages/cashiers.php" class="nav-item <?= $nav_active === 'cashiers' ? 'active' : '' ?>" onclick="closeSidebar()">
        <span class="icon"><i class="fa fa-users"></i></span> Kasir
      </a>

      <div class="nav-section">Akun</div>
      <a href="<?= BASE_URL ?>/pages/profile.php" class="nav-item <?= $nav_active === 'profile' ? 'active' : '' ?>" onclick="closeSidebar()">
        <span class="icon"><i class="fa fa-user-circle"></i></span> Profile
      </a>
    </nav>

    <div class="sidebar-footer">
      <div class="cashier-info">
        <div class="cashier-avatar"><?= strtoupper(substr($cashier['username'], 0, 1)) ?></div>
        <div>
          <div class="cashier-name"><?= e($cashier['username']) ?></div>
          <div class="cashier-role">Kasir</div>
        </div>
      </div>
      <a href="<?= BASE_URL ?>/logout.php" class="btn-logout">
        <i class="fa fa-right-from-bracket"></i> Logout
      </a>
    </div>
  </aside>

  <!-- MAIN -->
  <main class="main">
    <div class="topbar no-print">
      <div class="flex gap-8" style="align-items:center">
        <button class="btn btn-ghost btn-icon" id="sidebar-toggle" onclick="toggleSidebar()" style="display:none">
          <i class="fa fa-bars"></i>
        </button>
        <div class="page-title"><?= e($page_title ?? 'Dashboard') ?></div>
      </div>
      <div class="topbar-right">
        <div class="clock" id="clock"></div>
      </div>
    </div>

    <div class="content">
      <?php
      $flash = get_flash();
      if ($flash): ?>
        <div class="flash flash-<?= e($flash['type']) ?>">
          <i class="fa <?= $flash['type'] === 'success' ? 'fa-check-circle' : 'fa-triangle-exclamation' ?>"></i>
          <?= e($flash['msg']) ?>
        </div>
      <?php endif; ?>
