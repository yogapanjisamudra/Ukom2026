<?php
// This file can be included inline or used standalone
// Expects $last_trx array or $trx_data array from transaction
if (!isset($last_trx) && isset($trx_data)) {
    $last_trx = $trx_data;
}
if (!isset($last_trx)) return;
$items = is_string($last_trx['items']) ? json_decode($last_trx['items'], true) : $last_trx['items'];
$products = isset($last_trx['products']) ? (is_string($last_trx['products']) ? json_decode($last_trx['products'], true) : $last_trx['products']) : $items;
if (!$items && $products) $items = $products;
?>
<div class="receipt" id="receiptPrint" style="margin:0 auto;max-width:300px;background:#fff;color:#000;font-family:'Courier New',monospace;font-size:12px;line-height:1.6;padding:16px;">
  <div class="store-name" style="font-size:16px;font-weight:bold;text-align:center;"><?= e(STORE_NAME) ?></div>
  <div class="store-info" style="text-align:center;font-size:11px;"><?= e(STORE_LOCATION) ?></div>
  <div class="divider" style="border-top:1px dashed #000;margin:8px 0;"></div>
  <div style="font-size:11px;margin-bottom:4px;">
    <div>No. : <strong><?= e($last_trx['kode']) ?></strong></div>
    <div>Kasir: <?= e($last_trx['cashier'] ?? $last_trx['cashier_name'] ?? '-') ?></div>
    <div>Tgl  : <?= date('d/m/Y H:i', strtotime($last_trx['time'] ?? $last_trx['created_at'] ?? 'now')) ?></div>
  </div>
  <div class="divider" style="border-top:1px dashed #000;margin:8px 0;"></div>

  <?php if ($items): foreach ($items as $item): ?>
  <div class="item-row" style="display:flex;justify-content:space-between;">
    <span><?= e($item['name'] ?? $item['product_name'] ?? '-') ?></span>
    <span>Rp <?= number_format(($item['final'] ?? $item['final_price'] ?? $item['price']) * ($item['qty'] ?? 1), 0, ',', '.') ?></span>
  </div>
  <div style="font-size:10px;color:#555;margin-bottom:2px;">
    <?= ($item['qty'] ?? 1) ?> × Rp <?= number_format($item['final'] ?? $item['final_price'] ?? $item['price'], 0, ',', '.') ?>
    <?php if (($item['discount'] ?? 0) > 0): ?>
    (disc <?= $item['discount'] ?>%)
    <?php endif; ?>
  </div>
  <?php endforeach; endif; ?>

  <div class="divider" style="border-top:1px dashed #000;margin:8px 0;"></div>
  <div class="total-row" style="display:flex;justify-content:space-between;font-weight:bold;">
    <span>TOTAL</span>
    <span>Rp <?= number_format($last_trx['grand_total'] ?? 0, 0, ',', '.') ?></span>
  </div>
  <div style="display:flex;justify-content:space-between;font-size:12px;">
    <span>Bayar</span>
    <span>Rp <?= number_format($last_trx['paid'] ?? 0, 0, ',', '.') ?></span>
  </div>
  <div style="display:flex;justify-content:space-between;font-size:12px;">
    <span>Kembali</span>
    <span>Rp <?= number_format(($last_trx['change'] ?? ($last_trx['paid'] ?? 0) - ($last_trx['grand_total'] ?? 0)), 0, ',', '.') ?></span>
  </div>
  <div class="divider" style="border-top:1px dashed #000;margin:8px 0;"></div>
  <div class="thank-you" style="text-align:center;margin-top:8px;font-size:11px;">
    Terima kasih sudah berbelanja!<br>
    <?= e(STORE_NAME) ?> — <?= e(STORE_LOCATION) ?>
  </div>
</div>
