    </div><!-- .content -->
  </main>
</div><!-- .layout -->

<!-- Confirm Dialog -->
<div class="confirm-overlay" id="confirmOverlay">
  <div class="confirm-box">
    <div class="icon" id="confirmIcon">⚠️</div>
    <h3 id="confirmTitle">Konfirmasi</h3>
    <p id="confirmMsg">Apakah kamu yakin?</p>
    <div class="confirm-actions">
      <button class="btn btn-secondary" onclick="closeConfirm()">Batal</button>
      <button class="btn btn-danger" id="confirmOkBtn">Ya, Lanjutkan</button>
    </div>
  </div>
</div>

<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
</body>
</html>
