// Samudra Store - Main JS

// Clock
function updateClock() {
  var el = document.getElementById('clock');
  if (!el) return;
  var now = new Date();
  var days = ['Min','Sen','Sel','Rab','Kam','Jum','Sab'];
  var d = days[now.getDay()];
  var time = now.toLocaleTimeString('id-ID', {hour:'2-digit', minute:'2-digit', second:'2-digit'});
  el.textContent = d + ', ' + time;
}
setInterval(updateClock, 1000);
updateClock();

// Mobile sidebar toggle
function toggleSidebar() {
  var sidebar = document.getElementById('sidebar');
  var overlay = document.getElementById('sidebarOverlay');
  sidebar.classList.toggle('open');
  overlay.classList.toggle('open');
}

function closeSidebar() {
  var sidebar = document.getElementById('sidebar');
  var overlay = document.getElementById('sidebarOverlay');
  if (sidebar) sidebar.classList.remove('open');
  if (overlay) overlay.classList.remove('open');
}

// Show toggle button on mobile
function checkMobile() {
  var btn = document.getElementById('sidebar-toggle');
  if (!btn) return;
  if (window.innerWidth <= 768) {
    btn.style.display = 'flex';
  } else {
    btn.style.display = 'none';
    closeSidebar();
  }
}
checkMobile();
window.addEventListener('resize', checkMobile);

// Confirm dialog
var confirmCallback = null;
function showConfirm(title, msg, icon, cb) {
  document.getElementById('confirmTitle').textContent = title;
  document.getElementById('confirmMsg').textContent = msg;
  document.getElementById('confirmIcon').textContent = icon || '⚠️';
  confirmCallback = cb;
  document.getElementById('confirmOverlay').classList.add('open');
}
function closeConfirm() {
  document.getElementById('confirmOverlay').classList.remove('open');
  confirmCallback = null;
}
var confirmOkBtn = document.getElementById('confirmOkBtn');
if (confirmOkBtn) {
  confirmOkBtn.addEventListener('click', function() {
    if (confirmCallback) confirmCallback();
    closeConfirm();
  });
}
var confirmOverlay = document.getElementById('confirmOverlay');
if (confirmOverlay) {
  confirmOverlay.addEventListener('click', function(e) {
    if (e.target === this) closeConfirm();
  });
}

// Modal helpers
function openModal(id) {
  var m = document.getElementById(id);
  if (m) m.classList.add('open');
}
function closeModal(id) {
  var m = document.getElementById(id);
  if (m) m.classList.remove('open');
}
document.addEventListener('click', function(e) {
  if (e.target.classList.contains('modal-overlay')) {
    e.target.classList.remove('open');
  }
});

// Format rupiah
function formatRp(n) {
  return 'Rp ' + Math.round(n).toLocaleString('id-ID');
}

// Flash auto-hide
setTimeout(function() {
  var flash = document.querySelector('.flash');
  if (flash) {
    flash.style.transition = 'opacity 0.5s';
    flash.style.opacity = '0';
    setTimeout(function(){ if(flash.parentNode) flash.parentNode.removeChild(flash); }, 500);
  }
}, 4000);
