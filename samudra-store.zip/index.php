<?php
require_once 'config.php';
require_login();

$conn = db();

$total_products = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM products"))['c'];
$total_categories = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM categories"))['c'];
$total_cashiers = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM cashiers"))['c'];
$today_trx = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c, COALESCE(SUM(grand_total),0) as total FROM transactions WHERE DATE(created_at) = CURDATE()"));
$month_trx = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c, COALESCE(SUM(grand_total),0) as total FROM transactions WHERE MONTH(created_at)=MONTH(CURDATE()) AND YEAR(created_at)=YEAR(CURDATE())"));
$low_stock = mysqli_query($conn, "SELECT p.*, c.nama as cat_name FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.stock <= 5 ORDER BY p.stock ASC LIMIT 8");
$recent_trx = mysqli_query($conn, "SELECT t.*, ca.username as cashier_name FROM transactions t LEFT JOIN cashiers ca ON ca.id=t.cashier_id ORDER BY t.created_at DESC LIMIT 6");

$page_title = 'Dashboard';
require_once 'includes/header.php';
?>

<div class="stats-grid">
  <div class="stat-card blue">
    <div class="stat-label">Transaksi Hari Ini</div>
    <div class="stat-value"><?= $today_trx['c'] ?></div>
    <div class="stat-sub">Rp <?= number_format($today_trx['total'], 0, ',', '.') ?></div>
  </div>
  <div class="stat-card green">
    <div class="stat-label">Omzet Bulan Ini</div>
    <div class="stat-value" style="font-size:20px">Rp <?= number_format($month_trx['total'], 0, ',', '.') ?></div>
    <div class="stat-sub"><?= $month_trx['c'] ?> transaksi</div>
  </div>
  <div class="stat-card yellow">
    <div class="stat-label">Total Produk</div>
    <div class="stat-value"><?= $total_products ?></div>
    <div class="stat-sub"><?= $total_categories ?> kategori</div>
  </div>
  <div class="stat-card red">
    <div class="stat-label">Total Kasir</div>
    <div class="stat-value"><?= $total_cashiers ?></div>
    <div class="stat-sub">Akun terdaftar</div>
  </div>
</div>

<div class="form-row cols-2" style="gap:20px">
  <div class="card">
    <div class="card-header">
      <div class="card-title"><i class="fa fa-triangle-exclamation" style="color:var(--yellow)"></i> Stok Menipis</div>
      <a href="<?= BASE_URL ?>/pages/products.php" class="btn btn-ghost btn-sm">Lihat Semua</a>
    </div>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Produk</th><th>SKU</th><th>Stok</th></tr></thead>
        <tbody>
          <?php if (mysqli_num_rows($low_stock) === 0): ?>
          <tr><td colspan="3" class="text-center text-muted" style="padding:20px">Semua stok aman 👍</td></tr>
          <?php else: while ($row = mysqli_fetch_assoc($low_stock)): ?>
          <tr>
            <td>
              <div style="font-weight:600;color:var(--text)"><?= e($row['name']) ?></div>
              <div style="font-size:11px;color:var(--text3)"><?= e($row['cat_name']) ?></div>
            </td>
            <td class="td-mono"><?= e($row['sku']) ?></td>
            <td><span class="badge <?= $row['stock'] == 0 ? 'badge-red' : 'badge-yellow' ?>"><?= $row['stock'] ?> pcs</span></td>
          </tr>
          <?php endwhile; endif; ?>
        </tbody>
      </table>
    </div>
  </div>
  <div class="card">
    <div class="card-header">
      <div class="card-title"><i class="fa fa-receipt" style="color:var(--accent)"></i> Transaksi Terbaru</div>
      <a href="<?= BASE_URL ?>/pages/transactions.php" class="btn btn-ghost btn-sm">Lihat Semua</a>
    </div>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Kode</th><th>Kasir</th><th>Total</th><th>Waktu</th></tr></thead>
        <tbody>
          <?php if (mysqli_num_rows($recent_trx) === 0): ?>
          <tr><td colspan="4" class="text-center text-muted" style="padding:20px">Belum ada transaksi</td></tr>
          <?php else: while ($row = mysqli_fetch_assoc($recent_trx)): ?>
          <tr>
            <td class="td-mono" style="font-size:11px"><?= e($row['kode']) ?></td>
            <td><?= e($row['cashier_name']) ?></td>
            <td style="color:var(--green);font-weight:600">Rp <?= number_format($row['grand_total'], 0, ',', '.') ?></td>
            <td style="font-size:11px;color:var(--text3)"><?= date('H:i', strtotime($row['created_at'])) ?></td>
          </tr>
          <?php endwhile; endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php require_once 'includes/footer.php'; ?>
